/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 3
- L'instruction scanf()

Programme
Saisie format�e de plusieurs nombres
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib;
 float fx;

 printf ("Entrez deux nombres entiers et un nombre d�cimal :");
 scanf("%d $ %d $ %f", &ia, &ib, &fx);
 printf ("Les nombres sont %d, %d et %f", ia, ib, fx);
 getch();
}

/*------------------------------
Explications :

scanf("%d $ %d $ %f", &ia, &ib, &fx);

A cause du $ dans le format, les nombres ne sont correctement lus et 
restitu�s que si on tape un $ entre chaque entr�e. En principe on �vite 
d'introduire des caract�res ou des commentaies suppl�mentaires dans la 
commande scanf. On se contente des formats des donn�es.

-----------------------------------*/
