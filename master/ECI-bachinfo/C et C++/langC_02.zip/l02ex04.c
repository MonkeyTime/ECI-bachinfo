/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 4
- L'instruction scanf()

Programme
Saisir un caract�re isol�
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib;
 char opx;

 printf ("Entrez deux nombres entiers et un operateur (+ - * /) :");
 scanf("%d %d %c", &ia, &ib, &opx);
 printf ("L'operation demandee : %d %c %d", ia, opx, ib);
 getch();

}

/*------------------------------
Explications :

scanf("%d %d %c", &ia, &ib, &opx);

La saisie d'un seul caract�re pose probl�me car, pour le programme 
l'espace est un caract�re, de m�me que le saut de ligne [return]. Pour 
que la lecture se fasse correctement, il faut introduire les donn�es en 
une seule ligne, s�par�es par des espaces, et non en trois fois.

-----------------------------------*/
