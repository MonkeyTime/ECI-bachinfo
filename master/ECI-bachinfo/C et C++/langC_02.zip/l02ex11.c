/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 11
- Les op�rateurs d'extraction et de comparaison de bits

Programme
Lire un nombre entier
Afficher si ce nombre est pair ou impair
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 unsigned int iNbre;

 clrscr();
 printf ("Entrez un nombre : ");
 scanf ("%u", &iNbre);
 if (iNbre & 0x0001)
	printf ("\nNombre impair");
 else
	printf ("\nNombre pair");
 getch();
}

/*------------------------------
Explications :

La variable iDiv a disparu

if (iNbre & 0x0001)
Un nombre est impair si le dernier bit (bit de poids faible ou bit de 
rang 1) a la valeur 1. S'il est pair, le dernier bit � la valeur 0. En 
effet tous les autres bits sont des multiples de 2. Pour extraire ce 
dernier bit du nombre, il suffit de faire un ET logique bit � bit avec 
la valeur hexad�cimale 0x0001 (dont le seul bit positionn� � 1 est au 
m�me endroit que le bit que l'on veut extaire.

Si iNbre = 25, alors
iNbre  		= 00011001
0x0001 		= 00000001
ET bit � bit= 00000001
  
Si iNbre = 44, alors
iNbre  		= 00101100
0x0001 		= 00000001
ET bit � bit= 00000000

Par cons�quent, l'expression
iNbre & 0x0001 = 1 si impair
iNbre & 0x0001 = 0 si pair

Notez que rien n'impose d'utiliser une notation hexad�cimale pour 
0x0001. On aurait tout aussi bien pu �crire (iNbre & 1) Cependant, la 
notation hexad�cimale attire l'attention du lecteur de ce programme sur 
le fait qu'on s'int�resse surtout � la structure binaire du nombre

Ce programme est encore plus rapide que le pr�c�dent
------------------------------*/
