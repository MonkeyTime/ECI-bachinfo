/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 8
- if...else embo�t�s

Programme
Lire deux nombres r�els
lire un op�rateur + - * /
faire l'op�ration demand�e
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float fa, fb, resu;
 char opx;

 clrscr();
 printf ("Entrez deux nombres entiers :");
 scanf("%f %f", &fa, &fb);
 printf ("Entrez un operateur (+ - * /) :");
 opx = getch();

 if (opx == '+')
	 resu = fa+fb;
 else if (opx == '-')
	 resu = fa-fb;
 else if (opx == '*')
	 resu = fa*fb;
 else if (opx == '/')
	 resu = fa/fb;
 else
    {
     resu=0;
	 printf ("\nVous avez introduit %c et non + - * /\n", opx);
    }

 printf ("\n%f %c %f = %f\n", fa, opx, fb, resu);
 getch();
}

/*------------------------------
Explications :

if (opx == '+')
:
else if (opx == '-')

La s�quence de tests se lit:
si opx est �gal � +
	alors, faire une addition
	sinon, si opx est �gal � -
		   alors, faire une soustraction
		   sinon, si opx est �gal � *
				  alors, faire une multiplication
				  sinon, si opx est �gal � /
						 alors, faire une division,
						 sinon, c'est qu'on n'a pas introduit l'une des 
							    valeurs ci-dessus

Dans le cas pr�sent, on ne teste pas si le diviseur est bien diff�rent 
de 0

------------------------------*/
