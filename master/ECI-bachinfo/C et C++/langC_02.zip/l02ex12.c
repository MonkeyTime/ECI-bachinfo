/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 12
- L'instruction switch...case

Programme
Calculatrice �l�mentaire qui demande deux nombres
et un op�rateur arithm�tique et qui affiche le r�sultat
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float x, y, resu;
 char opx;
 
 printf ("Entrez deux nombres: ");
 scanf ("%f%f",&x,&y);
 printf ("Entrez + - * / ");
 opx=getch();
 
 resu=0;
 switch (opx)
        {
         case '+' : 
         	resu=x+y;
         	break;
         case '-' :
         	resu=x-y;
         	break;
         case '*' :
         	resu=x*y;
         	break;
         case '/' :
            if (y)
         		resu=x/y;
         	else
         		printf ("\ndivision par 0");
         	break;
         default :
            printf ("\nVous n'avez pas entr� + - * /");
		}

 printf ("\n%9.3f %c %9.3f = %9.3f\n", x, opx, y, resu);
 getch();
}

/*------------------------------
Explications :

switch (opx)
opx contient la valeur qui va �tre test�e dans chaque "case". C'est 
obligatoirement une valeur de type entier (long, int, char) ou une 
instruction dont le r�sultat est un entier.

case '+' :
'+' repr�sente le caract�re +. Son code Ascii est 43 (d�cimal). Il 
s'agit donc �galement d'un nombre entier. Contrairement � d'autres 
langages, C n'admet pas un plage de valeurs dans l'instruction "case".

break; 
Provoque la sortie et le saut � l'instruction qui suit le bloc 
switch{}. En absence de break, l'execution se poursuit dans le "case" 
suivant. 

default:
Instruction (optionnelle) qui est ex�cut�e si le programme n'a pu 
trouver aucune correspondance entre opx et l'un des "case". Si 
l'instruction "default" est pr�sente, elle est obligatoirement plac�e en 
fin de bloc. Elle ne doit pas �tre suivie de "break" puisqu'on sort de 
toutes fa�ons.

printf ("%9.3f", x);
Les nombres affich�s par printf peuvent �tre format�s. Dans le cas 
pr�sent il s'agit d'un nombre flottant qui occupe 9 caract�res (point 
d�cimal compris) dont 3 apr�s la virgule : xxxxx.xxx
Notez que le type float ne donne que 7 � 8 chiffres significatifs.  Pour 
plus de pr�cision, il faut employer le type double

------------------------------*/
