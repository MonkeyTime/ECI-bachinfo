/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 12
- L'instruction switch...case

Programme
Calculatrice �l�mentaire qui demande deux nombres
et un op�rateur arithm�tique et qui affiche le r�sultat
M�me programme mais avec un indicateur d'erreur
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float x, y, resu;
 char opx;
 int ierror;
 
 clrscr();
 printf ("Entrez deux nombres: ");
 scanf ("%f%f",&x,&y);
 printf ("Entrez + - * / ");
 opx=getch();
 
 resu=0;
 ierror=0;
 switch (opx)
        {
         case '+' : 
         	resu=x+y;
         	break;
         case '-' :
         	resu=x-y;
         	break;
         case '*' :
         	resu=x*y;
         	break;
         case '/' :
            if (y)
         		resu=x/y;
         	else
				ierror=1;
         	break;
         default :
			ierror=2;
		}

 if (ierror)
	 printf ("\nErreur %d :\n1 = division par 0\n2 = Vous n'avez pas entr� + - * /", ierror);
 else
	 printf ("\n%9.3f %c %9.3f = %9.3f\n", x, opx, y, resu);
 getch();
}

/*------------------------------
Explications :

Les programmes se composent souvent de trois parties
- une partie de saisie des informations
- une partie de calcul
- une partie d'affichage des r�sultats

On �vite de m�langer les saisies et les affichages avec le calcul 
proprement dit. En cas de probl�me, on d�finit un code d'erreur qui sera 
comment� dans la partie "affichage".
------------------------------*/
