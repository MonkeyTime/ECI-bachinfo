/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 7
- if...else (simple)

Programme
Lire deux nombres r�els
lire un op�rateur + ou -
faire l'op�ration demand�e
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float fa, fb, resu;
 char opx;

 clrscr();
 printf ("Entrez deux nombres quelconques :");
 scanf("%f %f", &fa, &fb);
 printf ("Entrez\n+ pour une addition\n- pour une soustraction :");
 opx = getch();

 if (opx == '+')
	 resu=fa+fb;
 else
	 resu=fa-fb;

 printf ("\n%f %c %f = %f\n", fa, opx, fb, resu);
 getch();
}

/*------------------------------
Explications :

if (opx == '+')
l'instruction if effectue un test dont la r�ponse est VRAI ou FAUX. Dans 
le cas pr�sent, le test se lit "le caract�re stock� dans opx est-il le 
caract�re + ?". Si c'est le cas, le test � la valeur VRAI et la ligne 
plac�e apr�s le "if" suivante est ex�cut�e. Si la valeur est FAUX, c'est 
la ligne plac�e apr�s le mot-cl� "else" qui est effectu�e. S'il n'y a 
pas de clause "else" et que le test est FAUX, le programme saute 
simplement la ligne (ou le bloc) plac� apr�s le "if".

Quand plusieurs instructions doivent �tre ex�cut�es dans le cas VRAI ou 
dans le cas FAUX, on les place entre acollades {}.

L'op�rateur d'�galit� est == et non = (= est l'op�rateur d'affectation)
L'op�rateur d'in�galit� est != et non <> (cas du VB) 

Remarquez que la "else" est ex�cut�e dans tous les cas o� le caract�re 
entr� n'est pas '+'. Autrement dit, si on entre n'importe quoi comme 
op�rateur, le programme fera une soustraction !

------------------------------*/
