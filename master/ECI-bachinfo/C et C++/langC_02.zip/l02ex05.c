/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 5
- L'instruction getch()

Programme
Saisir un caract�re isol�
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib;
 char opx;

 clrscr();
 printf ("Entrez deux nombres entiers :");
 scanf("%d %d", &ia, &ib);
 printf ("Entrez un operateur (+ - * /) :");
 opx = getch();
 printf ("L'operation demandee : %d %c %d", ia, opx, ib);
 getch();

}

/*------------------------------
Explications :

clrscr();
clrscr (Clear screen) provoque l'effacement de l'�cran et le 
repositionnement du curseur dans le coin sup�rieur gauche.

opx = getch();
getch est la fonction qui permet de saisi sans probl�me la frappe d'un 
caract�re isol�. La mise en m�moire du caract�re lu dans la variable opx 
se fait par une instruction d'affectation classique.

-----------------------------------*/
