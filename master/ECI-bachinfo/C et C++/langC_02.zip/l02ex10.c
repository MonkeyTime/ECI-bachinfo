/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 10
- Les op�rateurs de d�calage de bits
- L'affectation compos�e

Programme
Lire un nombre entier
Afficher si ce nombre est pair ou impair
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 unsigned int iNbre, iDiv;

 clrscr();
 printf ("Entrez un nombre : ");
 scanf ("%u", &iNbre);
 iDiv = iNbre >> 1;
 iNbre -= iDiv << 1;
 if (iNbre)
	printf ("\nNombre impair");
 else
	printf ("\nNombre pair");
 getch();
}

/*------------------------------
Explications :

iDiv = iNbre >> 1;
Dans cette instruction, le motif binaire de iNbre est d�cal� de 1 rang 
vers la droite par l'op�rateur binaire >>.

Si iNbre=25 alors son motif binaire est 00011001.
Apr�s d�calage, il devient 00001100 (12).
Le dernier bit � droite est perdu et le premier bit � gauche est rempli 
avec un z�ro.  C'est la mani�re la plus rapide de r�aliser une division 
ENTIERE par 2. Pour une division enti�re par 4, on d�cale de 2 bits; 3 
bits pour une division par 8, etc.

iDiv << 1
Cette instruction est l'op�ration inverse. Le motif binaire de iDiv est 
d�cal� de 1 rang vers la gauche par l'op�rateur <<.
Si iDiv=12 alors son motif binaire est 00001100.
Apr�s d�calage, il devient 00011000 (24).
Le dernier bit � gauche est perdu et le premier bit � droite est rempli 
avec un z�ro.  C'est la mani�re la plus rapide de r�aliser une 
multiplication ENTIERE par 2.

iNbre -= iDiv << 1;
Quand la m�me variable appara�t des deux c�t�s du signe d'affectation, C 
propose une affectation compos�e qui est trait�e beaucoup plus 
rapidement par le processeur.
i = i+2;  devient i+=2;
f = f/3.; devient  f/=3.;
L'expression ci-dessus correspond �
iNbre = iNbre - (iDiv << 1) 

if (iNbre)
Ainsi qu'il a �t� dit dans l'exercice pr�c�dent, le test peut �tre 
n'importe quelle expression math�matique ou logique qui renvoie une 
valeur 0 (faux) ou diff�rente de 0 (et pas n�cessairement 1) qui a la 
valeur "vrai". Or, dans le cas pr�sent, iNbre contient pr�cis�ment la 
valeur 0 ou 1 selon que le nombre est pair ou impair. La comparaison
(iNbre == 1) est une redondance et une perte de temps.

Ce programme est plus rapide que le pr�c�dent
------------------------------*/
