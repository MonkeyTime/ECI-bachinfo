/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 9
- if...else embo�t�s

Programme
Lire deux nombres r�els
lire un op�rateur + - * /
faire l'op�ration demand�e
tester la division par 0;
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float fa, fb, resu;
 char opx;

 clrscr();
 printf ("Entrez deux nombres entiers :");
 scanf("%f %f", &fa, &fb);
 printf ("Entrez un operateur (+ - * /) :");
 opx = getch();

 if (opx == '+')			/* if (1) */
	 resu = fa+fb;
 else if (opx == '-')		/* else du if (1) et if (2) */
	 resu = fa-fb;
 else if (opx == '*')		/* else du if (2) et if (3) */
	 resu = fa*fb;
 else if (opx == '/')		/* else du if (3) et if (4) */
	  if (fb != 0.)			/* if (5) */
		 resu = fa/fb;
	  else					/* else du dernier if sans else = if (5) */
        {
         resu=0;
		 printf ("\ndivision par 0 interdite\n");
		}
 else						/* else du dernier if sans else = if (4) */
    {
     resu=0;
	 printf ("\nVous avez introduit %c et non + - * /\n", opx);
    }

 printf ("\n%f %c %f = %f\n", fa, opx, fb, resu);
 getch();
}

/*------------------------------
Explications :

else if (opx == '/')
	 if (fb != 0.)

Si on a demand� une division, alors le diviseur est-il diff�rent de 0?
Comme plusieurs instructions doivent �tre ex�cut�es, on les place dans 
des acollades {}.
Dans la s�quence if..if..else..else
Un "else" se rapporte toujours au dernier "if" qui n'a pas de "else"

------------------------------*/
