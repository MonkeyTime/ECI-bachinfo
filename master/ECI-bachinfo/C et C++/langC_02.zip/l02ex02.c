/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 2
- L'instruction scanf()

Programme
Saisir plusieurs nombres
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib;
 float fx;

 printf ("Entrez deux nombres entiers et un nombre d�cimal :");
 scanf("%d %d %f", &ia, &ib, &fx);
 printf ("Les nombres sont %d, %d et %f", ia, ib, fx);
 getch();
}

/*------------------------------
Explications :

scanf("%d %d %f", &ia, &ib, &fx);
De m�me que printf peut afficher le contenu de plusieurs variables en 
une seule instruction, scanf peut lire plusieurs variables dans l'ordre 
des formats sp�cifi�s.

Voyez ce qui se passe si vous introduisez des valeurs qui ne 
correspondent pas aux formats sp�cifi�s.
-----------------------------------*/
