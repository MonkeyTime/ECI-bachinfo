/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 6
- L'instruction if...else

Programme
Lire un nombre entier
Afficher si ce nombre est pair ou impair
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 unsigned int iNbre, iDiv;

 clrscr();
 printf ("Entrez un nombre : ");
 scanf ("%u", &iNbre);
 iDiv = iNbre / 2;
 iNbre = iNbre - 2*iDiv;
 if (iNbre == 1)
    {
	 printf ("\nNombre impair");
    }
 else
    {
	 printf ("\nNombre pair");
    } 
 getch();
}

/*------------------------------
Explications :

On sait qu'un nombre est pair ou impair selon que le reste de sa 
division par 2 est 0 ou 1.

unsigned int d�signe un entier non sign� (toujours positif) compris 
entre 0 et 65535. Le format printf/scanf est %u.
int d�signe un nombre entier sign� (positif ou n�gatif) compris entre 
-32768 et +32767.  Le format printf/scanf est %d.

iDiv = iNbre / 2;
La division de deux nombres entiers produit un r�sultat entier; la 
partie d�cimale �ventuelle est perdue.  Notez qu'il n'y a pas de point 
d�cimal apr�s 2. Sinon, 2. serait consid�r� comme un nombre r�el et C 
convertirait le contenu de iNbre en r�el avant de faire la division puis 
convertirait le r�sultat en entier non sign� avant de le stocker dans 
iDiv.

iNbre = iNbre - 2*iDiv;
Si iNbre �tait pair, alors multiplier iDiv par 2 va redonner iNbre. 
Sinon, le r�sultat de la multiplication sera inf�rieure d'une unit� � la 
valeur de iNbre � cause de la partie d�cimale qui s'est perdue lors de 
la division. Apr�s cette ligne iNbre contient soit 0, soit 1.

if (iNbre == 1)
Le test se met entre parenth�ses. Les op�rateurs de comparaison sont
== �gal
!= diff�rent
>  plus grand
>= plus grand ou �gal
<  plus petit
<= plus petit ou �gal
&& et (and)
|| ou (or)
!  non (not)

Notez le double = qui distingue l'op�rateur de comparaison de 
l'op�rateur d'affectation.

En r�alit�, le test peut �tre n'importe quelle expression math�matique 
ou logique qui renvoie une valeur 0 (faux) ou diff�rente de 0 (et pas 
n�cessairement 1) qui a la valeur "vrai".  Des expressions telles que
if (3.14159 * 0.1435) ou if ('A') seraient valides ainsi qu'on le verra 
dans les prochains exercices.

Les paragraphes d'instructions ex�cut�es dans le cas "if" et dans le cas 
"else" sont d�limit�s par des accolades {}. Dans le cas pr�sent, comme 
il n'y a qu'une seule instruction dans les deux branches du if...else, 
les accolades ne sont pas n�cessaires.  Notez cependant 
la pr�sence du point-virgule final dans chaque branche.

------------------------------*/
