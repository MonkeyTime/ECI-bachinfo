/*------------------------------
LANGAGE C - H. Schyns

Le�on 2 - Exercice 1
- L'instruction scanf()

Programme
Saisie de nombres
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia;

 printf ("Entrez un nombre :");
 scanf("%d", &ia);
 printf ("Le nombre entre est %d", ia);
 getch();

}

/*------------------------------
Explications :

scanf("%d", &ia);
La fonction de lecture du clavier scanf utilise les memes formats que 
printf. Notez le & (ampersand) devant le nom de la variable dans 
laquelle la valeur lue doit �tre stock�e : &ia repr�sente l'adresse 
m�moire de la variable ia. Nous aurons l'occasion d'y revenir plus en 
d�tail.

Essayez d'introduire des donnees qui n'ont pas le bon type pour voir 
comment le programme r�agit

-----------------------------------*/
