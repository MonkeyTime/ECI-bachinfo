/*--------------------------------------
Programme : discour7
Fichier : discou7.c
Auteur : H. Schyns
Version : 1.0
Date derniere modif : 11/03/2008
---------------------------------------*/
 
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*------------------ Prototypes ------------------*/

int Continuer(void);

void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMots,
		      int* pNbreLettres);

int FaireDiscours(int NbrePhrases,
		  int NbreMots,
		  int NbreLettres,
		  char *pDiscours);

void AfficherDiscours(char *pDiscours);

void TirerNombreMots(void);

int  FairePhrase(int NbreMots,
		 int NbreLettres,
		 char *pPhrase);

void TirerNombreLettres(void);

void FaireMot(int NbreLettres, char *pMot);

char TirerConsonne(void);

char TirerVoyelle(void);

void AfficherErreur(int NbrePhrases, int NbreMots, int NbreLettres);

/*------------------ Main ------------------*/

void main (void)
{
 int NbrePhrases;
 int NbreMots;
 int NbreLettres;
 int DiscoursLen;		/* longueur du discours	*/
 char *pDiscours;

 do
  {
   clrscr();
   SaisirParametres(&NbrePhrases, &NbreMots, &NbreLettres);
		/* alloc dyn de l'espace necessaire au discours */
   DiscoursLen = NbrePhrases *( NbreMots * (NbreLettres+1) + 1) + 10;
   pDiscours = (char *)malloc (DiscoursLen * sizeof(char));	
   if (pDiscours)
      {
       FaireDiscours(NbrePhrases, NbreMots, NbreLettres, pDiscours);
       AfficherDiscours(pDiscours);
       free (pDiscours);
      }
   else
      {
       AfficherErreur(NbrePhrases, NbreMots, NbreLettres);
      }
  } while (Continuer());
}

/*------------------ Routines ------------------*/

/*------------------------------------------*/
int Continuer(void)
/*------------------------------------------*/
{
 char cRep;
 int ival;

 printf ("Autre discours [O/N] ? ");
 cRep = getche() ;
 ival = (cRep=='o') || (cRep=='O');
 return(ival);
}

/*------------------------------------------*/
void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMots,
		      int* pNbreLettres)
/*------------------------------------------*/
{
 printf ("Entree dans SaisirParametres\n");

 do {
     printf ("Nombre de phrases du discours (>0) ? ");
     scanf ("%d", pNbrePhrases);
    }while(*pNbrePhrases <=0);

 do {
     printf ("Nombre de mots par phrase (>0) ? ");
     scanf ("%d", pNbreMots);
    }while(*pNbreMots <=0);

 do {
     printf ("Nombre de lettres par mot (>0) ? ");
     scanf ("%d", pNbreLettres);
    }while(*pNbreLettres <=0);

 printf ("Sortie de SaisirParametres\n");
}

/*------------------------------------------*/
int FaireDiscours(int NbrePhrases,
		  int NbreMots,
		  int NbreLettres,
		  char *pDiscours)
/*------------------------------------------*/
{
 int i;
 int ncar;
 char* pPhrase;

 /* printf ("Entree dans FaireDiscours\n"); */

       					/* alloc dynamique de la phrase */
 ncar = NbreMots * (NbreLettres + 1) + 10;
 pPhrase = (char *) malloc ( ncar*sizeof(char) );
 if (!pPhrase) return(0);		/* alloc OK ? */

 pDiscours[0]=0;

 for(i=0; i<NbrePhrases; i++)
    {
     TirerNombreMots();
     FairePhrase(NbreMots, NbreLettres, pPhrase);
     strcat (pDiscours, pPhrase);
     strcat (pDiscours,"\n");
    }

 free (pPhrase);                        /* rendre � l'OS	*/

/* printf ("FaireDiscours :\n%s\n", pDiscours); */
/* printf ("Sortie de FaireDiscours\n"); */
 return(1);
}

/*------------------------------------------*/
void AfficherDiscours(char *pDiscours)
/*------------------------------------------*/
{
 /* printf ("Entree dans AfficherDiscours\n"); */

 printf ("\nVOTRE DISCOURS\n"
	   "--------------\n\n"
	   "%s\nApplaudissez !\n\n", pDiscours);

 /* printf ("Sortie de AfficherDiscours\n"); */
}

/*------------------------------------------*/
void TirerNombreMots(void)
/*------------------------------------------*/
{
 printf ("\tEntree dans TirerNombreMots\n");
 printf ("\tSortie de TirerNombreMots\n");
}

/*------------------------------------------*/
int FairePhrase(int NbreMots, int NbreLettres, char *pPhrase)
/*------------------------------------------*/
{
 int i;
 int n;
 char *pMot;

 /* printf ("\tEntree dans FairePhrase\n"); */
				 /* allocation dynamique du mot */
 pMot = (char *)malloc( (NbreLettres+1)*sizeof(char) );
 if (!pMot) return(0);		 /* alloc OK ?			*/

 pPhrase[0]=0;			 /* phrase vide au d�part	*/

 for(i=0; i<NbreMots; i++)
    {
     TirerNombreLettres();
     FaireMot(NbreLettres, pMot);
     strcat (pPhrase, pMot);	 /* ajouter un mot � la phrase 	*/
     strcat (pPhrase, " ");
    }

 free (pMot);			 /* restitue l'espace � l'OS	*/

 pPhrase[0] &= 0xDF;		 /* premier caract�re en majuscule */
 n = strlen(pPhrase);		 /* longueur de la phrase	   */
 pPhrase[n-1] = '.';

 /* printf ("FairePhrase :\n%s\n", pPhrase); */
 /* printf ("\tSortie de FairePhrase\n"); */
 return(1);
}

/*------------------------------------------*/
void TirerNombreLettres(void)
/*------------------------------------------*/
{
 printf ("\t\tEntree dans TirerNombreLettres\n");
 printf ("\t\tSortie de TirerNombreLettres\n");
}

/*------------------------------------------*/
void FaireMot(int NbreLettres, char *pMot)
/*------------------------------------------*/
{
 int i;
 int k;

 /* printf ("\t\tEntree dans FaireMot\n"); */

 k=random(2);		/* 1 lettre voyelle ou consonne au hasard */

 for(i=0; i<NbreLettres; i++)
    {
     if (k)
	 pMot[i] = TirerConsonne();
     else
	 pMot[i] = TirerVoyelle();
     k=1-k;			/* flip / flop */
    }

 pMot[NbreLettres] = 0;		/* 0 final du mot */

/* printf ("FaireMot : %s\n", pMot);    */
/* printf ("\t\tSortie de FaireMot\n"); */
}

/*------------------------------------------*/
char TirerConsonne(void)
/*------------------------------------------*/
{
 char *consonnes = "bcdfghjklmnpqrstvwxz";
 int ncons;
 int i;

 /*  printf ("\t\t\tEntree dans TirerConsonne\n");  */

 ncons=strlen(consonnes);
 i=random(ncons);

 /*  printf ("Consonne : %2d - %c\n", i, consonnes[i]); */
 /*  printf ("\t\t\tSortie de TirerConsonne\n");  */

 return(consonnes[i]);
}

/*------------------------------------------*/
char TirerVoyelle(void)
/*------------------------------------------*/
{
 char *voyelles = "aeiouy";
 int nvoy;
 int i;

 /* printf ("\t\t\tEntree dans TirerVoyelle\n"); */

 nvoy = strlen(voyelles);
 i=random(nvoy);

 /*  printf ("Voyelle  : %2d - %c\n", i, voyelles[i]); */
 /*  printf ("\t\t\tSortie de TirerVoyelle\n"); */

 return(voyelles[i]);
}

/*------------------------------------------*/
void AfficherErreur(int NbrePhrases, int NbreMots, int NbreLettres)
/*------------------------------------------*/
{
 printf ("Pas assez d'espace memoire pour creer un discours\n"
         "de %d lignes de %d mots de %d lettres\n",
 	  NbrePhrases, NbreMots, NbreLettres);
}
