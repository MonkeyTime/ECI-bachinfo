/*--------------------------------------
Programme : discour1
Fichier : discou1.c
Auteur : H. Schyns
Version : 1.0
Date derniere modif : 04/03/2008
---------------------------------------*/
 
#include <conio.h>
#include <stdio.h>

/*------------------ Prototypes ------------------*/

int Continuer(void);
void SaisirParametres(int* pNbrePhrases, int* pNbreMots);
void FaireDiscours(int NbrePhrases, int NbreMots);
void AfficherDiscours(void);
void TirerNombreMots(void);
void FairePhrase(int NbreMots);
void TirerNombreLettres(void);
void FaireMot(void);
void TirerConsonne(void);
void TirerVoyelle(void);
void AjouterLettre(void);

/*------------------ Main ------------------*/

void main (void)
{
 int NbrePhrases;
 int NbreMots;

 do
  {
   clrscr();
   SaisirParametres(&NbrePhrases, &NbreMots);
   FaireDiscours(NbrePhrases, NbreMots);
   AfficherDiscours();
  } while (Continuer());
}

/*------------------ Routines ------------------*/

/*------------------------------------------*/
int Continuer(void)
/*------------------------------------------*/
{
 char cRep;
 int ival;

 printf ("Autre discours [O/N] ? ");
 cRep = getche() ;
 ival = (cRep=='o') || (cRep=='O');
 return(ival);
}

/*------------------------------------------*/
void SaisirParametres(int* pNbrePhrases, int* pNbreMots)
/*------------------------------------------*/
{
 printf ("Entree dans SaisirParametres\n");

 do {
     printf ("Nombre de phrases du discours (>0) ? ");
     scanf ("%d", pNbrePhrases);
    }while(*pNbrePhrases <=0);

 do {
     printf ("Nombre de mots par phrase (>0) ? ");
     scanf ("%d", pNbreMots);
    }while(*pNbreMots <=0);

 printf ("Sortie de SaisirParametres\n");
}

/*------------------------------------------*/
void FaireDiscours(int NbrePhrases, int NbreMots)
/*------------------------------------------*/
{
 int i;

 printf ("Entree dans FaireDiscours\n");

 for(i=0; i<NbrePhrases; i++)
    {
     TirerNombreMots();
     FairePhrase(NbreMots);
    }

 printf ("Sortie de FaireDiscours\n");
}

/*------------------------------------------*/
void AfficherDiscours(void)
/*------------------------------------------*/
{
 printf ("Entree dans AfficherDiscours\n");
 printf ("Sortie de AfficherDiscours\n");
}

/*------------------------------------------*/
void TirerNombreMots(void)
/*------------------------------------------*/
{
 printf ("\tEntree dans TirerNombreMots\n");
 printf ("\tSortie de TirerNombreMots\n");
}

/*------------------------------------------*/
void FairePhrase(int NbreMots)
/*------------------------------------------*/
{
 int i;

 printf ("\tEntree dans FairePhrase\n");

 for(i=0; i<NbreMots; i++)
    {
     TirerNombreLettres();
     FaireMot();
    }

 printf ("\tSortie de FairePhrase\n");
}

/*------------------------------------------*/
void TirerNombreLettres(void)
/*------------------------------------------*/
{
 printf ("\t\tEntree dans TirerNombreLettres\n");
 printf ("\t\tSortie de TirerNombreLettres\n");
}

/*------------------------------------------*/
void FaireMot(void)
/*------------------------------------------*/
{
 int i;
 int k;
 int NbreLettres = 3;

 printf ("\t\tEntree dans FaireMot\n");

 k=0;
 for(i=0; i<NbreLettres; i++)
    {
     if (k)
	 TirerConsonne();
     else
	 TirerVoyelle();
     k=1-k;			/* flip / flop */
     AjouterLettre();
    }

 printf ("\t\tSortie de FaireMot\n");
}

/*------------------------------------------*/
void TirerConsonne(void)
/*------------------------------------------*/
{
 printf ("\t\t\tEntree dans TirerConsonne\n");
 printf ("\t\t\tSortie de TirerConsonne\n");
}

/*------------------------------------------*/
void TirerVoyelle(void)
/*------------------------------------------*/
{
 printf ("\t\t\tEntree dans TirerVoyelle\n");
 printf ("\t\t\tSortie de TirerVoyelle\n");
}

/*------------------------------------------*/
void AjouterLettre(void)
/*------------------------------------------*/
{
 printf ("\t\t\tEntree dans AjouterLettre\n");
 printf ("\t\t\tSortie de AjouterLettre\n");
}
