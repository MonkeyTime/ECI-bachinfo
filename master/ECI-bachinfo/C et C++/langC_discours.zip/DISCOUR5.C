/*--------------------------------------
Programme : discour5
Fichier : discou5.c
Auteur : H. Schyns
Version : 1.0
Date derniere modif : 07/03/2008
---------------------------------------*/
 
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*------------------ Prototypes ------------------*/

int Continuer(void);
void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMots,
		      int* pNbreLettres);
void FaireDiscours(int NbrePhrases,
		   int NbreMots,
		   int NbreLettres);
void AfficherDiscours(void);
void TirerNombreMots(void);
void FairePhrase(int NbreMots,
                 int NbreLettres);
void TirerNombreLettres(void);
void FaireMot(int NbreLettres, char *pMot);
char TirerConsonne(void);
char TirerVoyelle(void);
void AjouterLettre(void);

/*------------------ Main ------------------*/

void main (void)
{
 int NbrePhrases;
 int NbreMots;
 int NbreLettres;

 do
  {
   clrscr();
   SaisirParametres(&NbrePhrases, &NbreMots, &NbreLettres);
   FaireDiscours(NbrePhrases, NbreMots, NbreLettres);
   AfficherDiscours();
  } while (Continuer());
}

/*------------------ Routines ------------------*/

/*------------------------------------------*/
int Continuer(void)
/*------------------------------------------*/
{
 char cRep;
 int ival;

 printf ("Autre discours [O/N] ? ");
 cRep = getche() ;
 ival = (cRep=='o') || (cRep=='O');
 return(ival);
}

/*------------------------------------------*/
void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMots,
		      int* pNbreLettres)
/*------------------------------------------*/
{
 printf ("Entree dans SaisirParametres\n");

 do {
     printf ("Nombre de phrases du discours (>0) ? ");
     scanf ("%d", pNbrePhrases);
    }while(*pNbrePhrases <=0);

 do {
     printf ("Nombre de mots par phrase (>0) ? ");
     scanf ("%d", pNbreMots);
    }while(*pNbreMots <=0);

 do {
     printf ("Nombre de lettres par mot (>0) ? ");
     scanf ("%d", pNbreLettres);
    }while(*pNbreLettres <=0);

 printf ("Sortie de SaisirParametres\n");
}

/*------------------------------------------*/
void FaireDiscours(int NbrePhrases, int NbreMots, int NbreLettres)
/*------------------------------------------*/
{
 int i;

 printf ("Entree dans FaireDiscours\n");

 for(i=0; i<NbrePhrases; i++)
    {
     TirerNombreMots();
     FairePhrase(NbreMots, NbreLettres);
     getch();
    }

 printf ("Sortie de FaireDiscours\n");
}

/*------------------------------------------*/
void AfficherDiscours(void)
/*------------------------------------------*/
{
 printf ("Entree dans AfficherDiscours\n");
 printf ("Sortie de AfficherDiscours\n");
}

/*------------------------------------------*/
void TirerNombreMots(void)
/*------------------------------------------*/
{
 printf ("\tEntree dans TirerNombreMots\n");
 printf ("\tSortie de TirerNombreMots\n");
}

/*------------------------------------------*/
void FairePhrase(int NbreMots, int NbreLettres)
/*------------------------------------------*/
{
 int i;
 int n;
 char Phrase[511];
 char Mot[255];

 /* printf ("\tEntree dans FairePhrase\n"); */

 Phrase[0]=0;			 /* phrase vide au d�part	*/	

 for(i=0; i<NbreMots; i++)
    {
     TirerNombreLettres();
     FaireMot(NbreLettres, Mot);
     strcat (Phrase, Mot);	 /* ajouter un mot � la phrase 	*/
     strcat (Phrase, " ");
    }

 Phrase[0] &= 0xDF;		 /* premier caract�re en majuscule */
 n = strlen(Phrase);		 /* longueur de la phrase	   */
 Phrase[n-1] = '.';
 	
 printf ("FairePhrase :\n%s\n", Phrase);

 /* printf ("\tSortie de FairePhrase\n"); */
}

/*------------------------------------------*/
void TirerNombreLettres(void)
/*------------------------------------------*/
{
 printf ("\t\tEntree dans TirerNombreLettres\n");
 printf ("\t\tSortie de TirerNombreLettres\n");
}

/*------------------------------------------*/
void FaireMot(int NbreLettres, char *pMot)
/*------------------------------------------*/
{
 int i;
 int k;

 /* printf ("\t\tEntree dans FaireMot\n"); */

 k=random(2);		/* 1 lettre voyelle ou consonne au hasard */

 for(i=0; i<NbreLettres; i++)
    {
     if (k)
	 pMot[i] = TirerConsonne();
     else
	 pMot[i] = TirerVoyelle();
     k=1-k;			/* flip / flop */
    }

 pMot[NbreLettres] = 0;		/* 0 final du mot */
 printf ("FaireMot : %s\n", pMot);

/* printf ("\t\tSortie de FaireMot\n"); */
}

/*------------------------------------------*/
char TirerConsonne(void)
/*------------------------------------------*/
{
 char *consonnes = "bcdfghjklmnpqrstvwxz";
 int ncons = 20;
 int i;

 /*  printf ("\t\t\tEntree dans TirerConsonne\n");  */

 i=random(ncons);

 /*  printf ("Consonne : %2d - %c\n", i, consonnes[i]); */
 /*  printf ("\t\t\tSortie de TirerConsonne\n");  */

 return(consonnes[i]);
}

/*------------------------------------------*/
char TirerVoyelle(void)
/*------------------------------------------*/
{
 char *voyelles = "aeiouy";
 int nvoy = 6;
 int i;

 /* printf ("\t\t\tEntree dans TirerVoyelle\n"); */

 i=random(nvoy);

 /*  printf ("Voyelle  : %2d - %c\n", i, voyelles[i]); */
 /*  printf ("\t\t\tSortie de TirerVoyelle\n"); */

 return(voyelles[i]);
}

/*------------------------------------------*/
void AjouterLettre(void)
/*------------------------------------------*/
{
 printf ("\t\t\tEntree dans AjouterLettre\n");
 printf ("\t\t\tSortie de AjouterLettre\n");
}
