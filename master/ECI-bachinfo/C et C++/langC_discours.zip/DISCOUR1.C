/*--------------------------------------
Programme : discour1
Fichier : discou1.c
Auteur : H. Schyns
Version : 1.0
Date derniere modif : 04/03/2008
---------------------------------------*/
 
#include <conio.h>
#include <stdio.h>

/*------------------ Prototypes ------------------*/

int Continuer(void);
void SaisirParametres(void);
void FaireDiscours(void);
void AfficherDiscours(void);
void TirerNombreMots(void);
void FairePhrase(void);

/*------------------ Main ------------------*/

void main (void)
{
 do
  {
   clrscr();
   SaisirParametres();
   FaireDiscours();
   AfficherDiscours();
  } while (Continuer());
}

/*------------------ Routines ------------------*/

/*------------------------------------------*/
int Continuer(void)
/*------------------------------------------*/
{
 char cRep;
 int ival;

 printf ("Autre discours [O/N] ? ");
 cRep = getche() ;
 ival = (cRep=='o') || (cRep=='O');
 return(ival);
}

/*------------------------------------------*/
void SaisirParametres(void)
/*------------------------------------------*/
{
 printf ("Entree dans SaisirParametres\n");
 printf ("Sortie de SaisirParametres\n");
}

/*------------------------------------------*/
void FaireDiscours(void)
/*------------------------------------------*/
{
 int NbrePhrases = 5;
 int i;

 printf ("Entree dans FaireDiscours\n");

 for(i=0; i<NbrePhrases; i++)
    {
     TirerNombreMots();
     FairePhrase();
    }

 printf ("Sortie de FaireDiscours\n");
}

/*------------------------------------------*/
void AfficherDiscours(void)
/*------------------------------------------*/
{
 printf ("Entree dans AfficherDiscours\n");
 printf ("Sortie de AfficherDiscours\n");
}

/*------------------------------------------*/
void TirerNombreMots(void)
/*------------------------------------------*/
{
 printf ("Entree dans TirerNombreMots\n");
 printf ("Sortie de TirerNombreMots\n");
}

/*------------------------------------------*/
void FairePhrase(void)
/*------------------------------------------*/
{
 printf ("Entree dans FairePhrase\n");
 printf ("Sortie de FairePhrase\n");
}

