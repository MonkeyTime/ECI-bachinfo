/*--------------------------------------
Programme : discour7
Fichier : discou7.c
Auteur : H. Schyns
Version : 1.0
Date derniere modif : 11/03/2008
---------------------------------------*/
 
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*------------------ Prototypes ------------------*/

int Continuer(void);

void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMotsMin, int* pNbreMotsMax,
		      int* pNbreLettresMin, int* pNbreLettresMax);

int FaireDiscours(int NbrePhrases,
		  int NbreMotsMin, int NbreMotsMax,
		  int NbreLettresMin, int NbreLettresMax,
		  char *pDiscours);

void AfficherDiscours(char *pDiscours);

int TirerNombre(int vmin, int vmax);

int FairePhrase(int NbreMots,
		int NbreLettresMin, int NbreLettresMax,
		char *pPhrase);

void FaireMot(int NbreLettres, char *pMot);

char TirerConsonne(void);

char TirerVoyelle(void);

void AfficherErreur(int NbrePhrases, int NbreMots, int NbreLettres);

/*------------------ Main ------------------*/

void main (void)
{
 int NbrePhrases;
 int NbreMotsMin, NbreMotsMax ;
 int NbreLettresMin, NbreLettresMax;
 int DiscoursLen;		/* longueur du discours	*/
 char *pDiscours;

 do
  {
   clrscr();
   SaisirParametres(&NbrePhrases,
		    &NbreMotsMin, &NbreMotsMax,
		    &NbreLettresMin, &NbreLettresMax);
		/* alloc dyn de l'espace necessaire au discours */
   DiscoursLen = NbrePhrases *( NbreMotsMax * (NbreLettresMax+1) + 1) + 10;
   pDiscours = (char *)malloc (DiscoursLen * sizeof(char));	
   if (pDiscours)
      {
       FaireDiscours(NbrePhrases,
		     NbreMotsMin, NbreMotsMax,
		     NbreLettresMin, NbreLettresMax,
		     pDiscours);
       AfficherDiscours(pDiscours);
       free (pDiscours);
      }
   else
      {
       AfficherErreur(NbrePhrases, NbreMotsMax, NbreLettresMax);
      }
  } while (Continuer());
}

/*------------------ Routines ------------------*/

/*------------------------------------------*/
int Continuer(void)
/*------------------------------------------*/
{
 char cRep;
 int ival;

 printf ("Autre discours [O/N] ? ");
 cRep = getche() ;
 ival = (cRep=='o') || (cRep=='O');
 return(ival);
}

/*------------------------------------------*/
void SaisirParametres(int* pNbrePhrases,
		      int* pNbreMotsMin, int* pNbreMotsMax,
		      int* pNbreLettresMin, int* pNbreLettresMax)
/*------------------------------------------*/
{
/* printf ("Entree dans SaisirParametres\n"); */

 do {
     printf ("Nombre de phrases du discours (>0) ? ");
     scanf ("%d", pNbrePhrases);
    }while(*pNbrePhrases <=0);
           	/* saisie du nombre MINIMUM de mots */
 do {
     printf ("Nombre min et max de  mots par phrase\n");
     printf ("Minimum (>0) ? ");
     scanf ("%d", pNbreMotsMin);
    }while(*pNbreMotsMin <=0);
		/* saisie du nombre MAXIMUM de mots */	
 do {
     printf ("Maximum (>=Minimum) ? ");
     scanf ("%d", pNbreMotsMax);
    }while(*pNbreMotsMax < *pNbreMotsMin);
		/* saisie du nombre MINIMUM de lettres */
 do {
     printf ("Nombre min et max de lettres par mot\n");
     printf ("Minimum (>0) ? ");
     scanf ("%d", pNbreLettresMin);
    }while(*pNbreLettresMin <=0);
		/* saisie du nombre MAXIMUM de lettres */
 do {
     printf ("Maximum (>=Minimum) ? ");
     scanf ("%d", pNbreLettresMax);
    }while(*pNbreLettresMax < *pNbreLettresMin);

/* printf ("Sortie de SaisirParametres\n"); */
}

/*------------------------------------------*/
int FaireDiscours(int NbrePhrases,
		  int NbreMotsMin, int NbreMotsMax,
		  int NbreLettresMin, int NbreLettresMax,
		  char *pDiscours)
/*------------------------------------------*/
{
 int i;
 int ncar;
 int NbreMots;
 char* pPhrase;

 /* printf ("Entree dans FaireDiscours\n"); */

       					/* alloc dynamique de la phrase */
 ncar = NbreMotsMax * (NbreLettresMax + 1) + 10;
 pPhrase = (char *) malloc ( ncar*sizeof(char) );
 if (!pPhrase) return(0);		/* alloc OK ? */

 pDiscours[0]=0;

 for(i=0; i<NbrePhrases; i++)
    {
    		/* tirer au hasard dans l'intervalle [min, max] */	
     NbreMots = TirerNombre(NbreMotsMin, NbreMotsMax);
     FairePhrase(NbreMots,
		 NbreLettresMin, NbreLettresMax,
		 pPhrase);
     strcat (pDiscours, pPhrase);
     strcat (pDiscours,"\n");
    }

 free (pPhrase);                        /* rendre � l'OS	*/

/* printf ("FaireDiscours :\n%s\n", pDiscours); */
/* printf ("Sortie de FaireDiscours\n"); */
 return(1);
}

/*------------------------------------------*/
void AfficherDiscours(char *pDiscours)
/*------------------------------------------*/
{
 /* printf ("Entree dans AfficherDiscours\n"); */

 printf ("\nVOTRE DISCOURS\n"
	   "--------------\n\n"
	   "%s\nApplaudissez !\n\n", pDiscours);

 /* printf ("Sortie de AfficherDiscours\n"); */
}

/*------------------------------------------*/
int TirerNombre(int vmin, int vmax)
/*------------------------------------------*/
{
 int vnombre;

/* printf ("\tEntree dans TirerNombreMots\n"); */

 vnombre = vmin + random(vmax-vmin+1);
 /* pour gcc
 vnombre = vmin + rand()%(vmax-vmin+1);
 */
/* printf ("\tSortie de TirerNombreMots\n"); */

 return (vnombre);
}

/*------------------------------------------*/
int FairePhrase(int NbreMots,
		int NbreLettresMin, int NbreLettresMax,
		char *pPhrase)
/*------------------------------------------*/
{
 int i;
 int n;
 int NbreLettres;
 char *pMot;

 /* printf ("\tEntree dans FairePhrase\n"); */
				 /* allocation dynamique du mot */
 pMot = (char *)malloc( (NbreLettresMax+1)*sizeof(char) );
 if (!pMot) return(0);		 /* alloc OK ?			*/

 pPhrase[0]=0;			 /* phrase vide au d�part	*/

 for(i=0; i<NbreMots; i++)
    {
    			/* tirer au hasard dans [min, max]	*/
     NbreLettres = TirerNombre(NbreLettresMin, NbreLettresMax);
     FaireMot(NbreLettres, pMot);
     strcat (pPhrase, pMot);	 /* ajouter un mot � la phrase 	*/
     strcat (pPhrase, " ");
    }

 free (pMot);			 /* restitue l'espace � l'OS	*/

 pPhrase[0] &= 0xDF;		 /* premier caract�re en majuscule */
 n = strlen(pPhrase);		 /* longueur de la phrase	   */
 pPhrase[n-1] = '.';

 /* printf ("FairePhrase :\n%s\n", pPhrase); */
 /* printf ("\tSortie de FairePhrase\n"); */
 return(1);
}

/*------------------------------------------*/
void FaireMot(int NbreLettres, char *pMot)
/*------------------------------------------*/
{
 int i;
 int k;

 /* printf ("\t\tEntree dans FaireMot\n"); */

 k=random(2);		/* 1 lettre voyelle ou consonne au hasard */

 for(i=0; i<NbreLettres; i++)
    {
     if (k)
	 pMot[i] = TirerConsonne();
     else
	 pMot[i] = TirerVoyelle();
     k=1-k;			/* flip / flop */
    }

 pMot[NbreLettres] = 0;		/* 0 final du mot */

/* printf ("FaireMot : %s\n", pMot);    */
/* printf ("\t\tSortie de FaireMot\n"); */
}

/*------------------------------------------*/
char TirerConsonne(void)
/*------------------------------------------*/
{
 char *consonnes = "bklmnrstv";
 int ncons;
 int i;

 /*  printf ("\t\t\tEntree dans TirerConsonne\n");  */

 ncons=strlen(consonnes);
 i=random(ncons);

 /*  printf ("Consonne : %2d - %c\n", i, consonnes[i]); */
 /*  printf ("\t\t\tSortie de TirerConsonne\n");  */

 return(consonnes[i]);
}

/*------------------------------------------*/
char TirerVoyelle(void)
/*------------------------------------------*/
{
 char *voyelles = "aiu";
 int nvoy;
 int i;

 /* printf ("\t\t\tEntree dans TirerVoyelle\n"); */

 nvoy = strlen(voyelles);
 i=random(nvoy);

 /*  printf ("Voyelle  : %2d - %c\n", i, voyelles[i]); */
 /*  printf ("\t\t\tSortie de TirerVoyelle\n"); */

 return(voyelles[i]);
}

/*------------------------------------------*/
void AfficherErreur(int NbrePhrases, int NbreMots, int NbreLettres)
/*------------------------------------------*/
{
 printf ("Pas assez d'espace memoire pour creer un discours\n"
         "de %d lignes de %d mots de %d lettres\n",
 	  NbrePhrases, NbreMots, NbreLettres);
}
