/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 5
- Les pointeurs et les vecteurs

Programme :
------------------------------*/
#include <conio.h>
#include <stdio.h>

#define VI_MAX 10
void main (void)
{
 int i;
 int ia[VI_MAX]={8,15,23,39,43,51,67,71,82,94}; /* initialisation */
 int *pix, *piy;

 clrscr();

 pix = ia;
 piy = &ia[0];
                    /* comparer les deux adresses */
 printf ("Adresse dans pix = %p  et dans piy = %p\n", pix, piy);

                    /* augmenter l'adresse de 5 unit�s */
 pix += 5;
 piy = &ia[5];
 printf ("Adresse dans pix = %p  et dans piy = %p\n", pix, piy);
 printf ("Contenu � l'adr pix = %i et piy = %i dans le vecteur = %i\n",
          *pix, *piy, ia[5]);

                    /* et si on proc�de en un seul coup ?*/
 pix=ia;
 printf ("Contenu � l'adr pix = %i et  dans le vecteur = %i\n",
          *(pix+8), ia[8]);

                    /* lister le vecteur en incr�mentant le pointeur */
 pix=ia;
 for (i=0; i< VI_MAX; i++, pix++)
      printf("composante [%d] = %d ou %d\n", i, ia[i], *pix);

 getch();
}
/*------------------------------
Explications :

 int ia[10]      tableau ou vecteur de 10 entiers
 int *pix, *piy  pointeurs sur un entier

Le tableau est initialis� lors de sa d�claration

En fait dans ia[10], ia est un pointeur.
On peut le copier tel quel dans l'autre pointeur.
On voit que la valeur est la m�me que si on prend l'adresse du premier �l�ment du tableau

si on d�place le pointeur de 5 �l�ments, on retombe sur la composante correspondante du tableau.  L'adresse a augment� de 10 bytes et non de 5 car le syst�me "sait" qu'il s'agit d'un pointeur sur entier et que les entiers ont une longueur de 2 bytes

Pour balayer un vecteur, on peut simplement incr�menter un pointeur qui a �t� initialis� � l'orgine du vecteur (pix++ et *pix)
Cette technique est beaucoup plus rapide que ia[i]

ATTENTION :
le pointeur de base du vecteur (ia) ne peut �tre modifi�.
Pas question de faire quelque chose comme (ia++ et *ia)
sinon il y a perte de m�moire � la sortie du module


------------------------------*/