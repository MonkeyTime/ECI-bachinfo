/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 6
- Les pointeurs et les vecteurs
  idem avec des doubles

Programme :
------------------------------*/
#include <conio.h>
#include <stdio.h>

#define VI_MAX 10
void main (void)
{
 int i;
 double da[VI_MAX]={0.8,1.5,2.3,3.9,4.3,5.1,6.7,7.1,8.2,9.4};
 double *pdx, *pdy;

 clrscr();

 pdx = da;
 pdy = &da[0];
                    /* comparer les deux adresses */
 printf ("Adresse dans pdx = %p  et dans pdy = %p\n", pdx, pdy);

                    /* augmenter l'adresse de 5 unit�s */
 pdx += 5;
 pdy = &da[5];
 printf ("Adresse dans pdx = %p  et dans pdy = %p\n", pdx, pdy);
 printf ("Contenu � l'adr pdx = %lf et pdy = %lf dans le vecteur = %lf\n",
          *pdx, *pdy, da[5]);

                    /* et si on proc�de en un seul coup ?*/
 pdx=da;
 printf ("Contenu � l'adr pdx = %lf et  dans le vecteur = %lf\n",
          *(pdx+8), da[8]);

                    /* lister le vecteur en incr�mentant le pointeur */
 pdx=da;
 for (i=0; i< VI_MAX; i++, pdx++)
      printf("composante [%d] = %lf ou %lf\n", i, da[i], *pdx);

 getch();
}
/*------------------------------
Explications :

M�me principe que l'exercice pr�c�dent mais avec un vecteur de doubles (8 bytes)

 int da[10]      tableau ou vecteur de 10 doubles
 int *pdx, *pdy  pointeurs sur un double

si on d�place le pointeur de 5 �l�ments, on retombe sur la composante correspondante du tableau.  L'adresse a augment� de 40 bytes et non de 5 car le syst�me "sait" qu'il s'agit d'un pointeur sur double et que les doubles ont une longueur de 8 bytes

Pour balayer un vecteur, on peut simplement incr�menter un pointeur qui a �t� initialis� � l'orgine du vecteur (pdx++ et *pdx)
Cette technique est beaucoup plus rapide que da[i] et sera utilis�e dans de nombreuses boucles.

La technique reste valable quel que soit le type du tableau ou vecteur.
------------------------------*/