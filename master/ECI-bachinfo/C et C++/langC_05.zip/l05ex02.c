/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 2
- Les pointeurs
- Op�rations sur les pointeurs

Programme :
Mettre des valeurs dans des variables
Modifier les valeurs et les adresses pour voir
ce qui se passe
------------------------------*/
#include <conio.h>
#include <stdio.h>
void main (void)
{
 int ia, ib;
 int *px, *py;
 clrscr();
                    /* stocker 18 dans ia et 25 dans ib */
 ia = 18;        
 ib = 25;
                    /* mettre les adresses dans les pointeurs */
 px = &ia;
 py = &ib;
                    /* afficher les adresses */  
 printf ("1) adresses stockees  px = %p  et py = %p\n", px, py);
 getch();
                    /* changer la valeur dans ia */
 ia *= 2;
                    /* afficher l'adresse et le contenu */  
 printf ( "2) adresses dans px = %p\n",
          "   contenu du pointeur *px = %d\n", px, *px);
 getch();
                    /* mettre le contenu du pointeur dans ib */
 ib = *px;
                    /* quelle est la valeur stock�e � l'adresse contenue
                       dans py? */
 printf ( "3) adresses dans py = %p\n",
          "   contenu du pointeur *py = %d\n", py, *py);
 getch();
                    /* modifions ib */
 ib += 10;
                    /* quelle est la valeur stock�e � l'adresse contenue
                       dans px? */
 printf ( "4) adresses dans px = %p\n",
          "   contenu du pointeur *px = %d\n", px, *px);
 getch();
                    /* donc ia n'a pas chang� */
 printf ( "5) valeur de ia = %d\n", ia);
 getch();
                    /* et si nous transf�rens les adresses ? */
 px = py;
                    /* quelle est la valeur stock�e � l'adresse contenue
                       dans px? */
 printf ( "6) adresses dans px = %p\n",
          "   contenu du pointeur *px = %d\n", px, *px);
 getch();
                    /* a-t-on modifi� ia ? */
 printf ( "7) valeur de ia = %d\n", ia);
 getch();
                    /* peut on modifier le pointeur ? */
 py += 20;
                    /* que trouve-t-on � cette adresse ? */
 printf ( "6) adresses dans py = %p\n",
          "   contenu du pointeur *py = %d\n", py, *py);
 getch();
}
/*------------------------------
Explications :

ia et ib sont des variables qui contiennent un entier
px et py sont des pointeurs sur un entier (int *),
Pour faire court, l'expression
*px
se lit g�n�ralement
"contenu du pointeur".
En toute rigueur il faut dire
"contenu de la memoire dont l'adresse est dans le pointeur"

Conclusion
Modifier une variable modifie le contenu du pointeur sur cette variable
mais le pointeur lui-m�me n'est pas modifi�.

On peut transf�rer les adresses de pointeur � pointeur

Modifier un pointeur est une op�ration d�licate car il peut pointeur sur
n'importe quelle zone de m�moire (y compris la m�moire video)
------------------------------*/