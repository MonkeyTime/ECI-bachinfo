/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 3
- Les pointeurs

Programme :
Les pointeurs eux-m�mes ont une adresse
------------------------------*/
#include <conio.h>
#include <stdio.h>
void main (void)
{
 int ia, ib;
 int *px;
 int **ppx;

 clrscr();

 ia = 18;       
 px = &ia;
                    /* afficher l'adresse de ia */ 
 printf ("1) adresse stockee  px = %p\n", px);
 getch();
                    /* afficher l'adresse du pointeur px */ 
 printf ("2) adresse du pointeur px = %p\n", &px);
 getch();
                    /* stocker l'adresse du pointeur
                       dans une autre pointeur */ 
 ppx = &px;
                    /* afficher l'adresse du pointeur px */ 
 printf ("3) adresse dans le pointeur de pointeur ppx = %p\n", ppx);
 getch();
                    /* retrouver la valeur ia et la mettre dans ib */
 ib = **ppx;
                    /* v�rifier ib */
 printf ("4) ib = %d ou **ppx = %d ou *px = %d\n", ib, **ppx, *px);
 getch();
}
/*------------------------------
Explications :

ia et ib sont des variables qui contiennent un entier
px est un pointeur sur un entier (int *),
ppx est un pointeur sur un pointeur sur un entier (int **)

ATTENTION
l'expression
ib = **ppx;
repr�sente effectivement un nombre
tandis que
ppx = &&ia;
n'a pas de sens

Les pointeurs de pointeurs sont utiles dans certains cas
que nous verrons plus tard tels que les tableaux de vecteurs.
Pour l'instant, il suffit de savoir que �a existe.
------------------------------*/