/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 4
- Les pointeurs de diff�rents types
- "cast" de pointeurs

Programme :
------------------------------*/
#include <conio.h>
#include <stdio.h>
void main (void)
{
 int ia;
 float fa;
 char ca;
 int *pix, *piy;
 float *pfx, *pfy;
 char *pcx, *pcy;

 clrscr();

 ia = 18;      
 pix = &ia;

 fa = 3.14159;
 pfx = &fa;

 ca='A';
 pcx = &ca;
                    /* afficher les adresse et les contenus */
 printf ("1) int  : adresse dans pix = %p  valeur = %d\n", pix, *pix);
 printf ("2) float: adresse dans pfx = %p  valeur = %f\n", pfx, *pfx);
 printf ("3) char : adresse dans pcx = %p  valeur = %c\n", pcx, *pcx);

                    /* tricher et transf�rer les pointeurs  */
 piy = (int *)pfx;  /* le ptr sur float devient un ptr sur int */   
 pfy = (float *)pcx;
 pcy = (char *)pix;

                    /* afficher les adresse et les contenus */
                    /* les adresses sont bien les m�mes mais */
                    /* le syst�me interpr�te mal les motifs binaires */
 printf ("1) int  : adresse dans piy = %p  valeur = %d\n", piy, *piy);
 printf ("2) float: adresse dans pfy = %p  valeur = %f\n", pfy, *pfy);
 printf ("3) char : adresse dans pcy = %p  valeur = %c\n", pcy, *pcy);

                    /* Et si on change le format d'affichage? */
                    /* ca ne marche pas mieux */
 printf ("1) int  : adresse dans piy = %p  valeur = %f\n", piy, *piy);
 printf ("2) float: adresse dans pfy = %p  valeur = %c\n", pfy, *pfy);
 printf ("3) char : adresse dans pcy = %p  valeur = %i\n", pcy, *pcy);

                    /* mais on peut refaire un cast */
                    /* au moment de l'affichage  */
 printf ("1) int  : adresse dans piy = %p  valeur = %f\n", piy, *(float
*)piy);
 printf ("2) float: adresse dans pfy = %p  valeur = %c\n", pfy, *(char
*)pfy);
 printf ("3) char : adresse dans pcy = %p  valeur = %i\n", pcy, *(int
*)pcy);
 getch();
}
/*------------------------------
Explications :

ia et ib sont des variables qui contiennent un entier
fa et fb sont des variables qui contiennent des r�els
pix et piy  sont des pointeurs sur un entier (int *)
pfx et pfy  sont des pointeurs sur des r�els (float *)

En r�alit�, tous les pointeurs ont une longueur de 8 bytes.
Les d�clarations int * ou float * servent uniquement au compilateur
quand il doit retrouver la _valeur_ stock�e � l'endroit indiqu� par le
pointeur�:
Si le pointeur a �t� d�clar� int *, il sait qu'il doit aller lire 2
bytes et les interpr�ter comme un entier
Si le pointeur a �t� d�clar� float *, il sait qu'il doit aller lire 4
bytes et les interpr�ter comme un r�el

Puisque les pointeurs ont tous une longueur de 8 bytes, on peut tricher
et transf�rer un pointeur d'un type vers un pointeur d'un autre type.
Cette op�ration peut ou non provoquer une erreur selon les options en
vigueur dans le compilateur.
Pour que �a marche dans tous les cas, il faut faire un "cast", c'est �
dire convertir explicitement le pointeur vers le type de destination
 piy = (int *)pfx;

Lors de la lecture, le syst�me est tromp�.  Bien que l'adresse soit
correcte (p.ex. l'adresse du float), il ne lit plus que 2 bytes qu'il
essaie d'interpr�ter comme un int.
Par contre, si on refait un "cast" au moment de l'affichage, tout rentre
dans l'ordre bien que le type des pointeurs soit erronn�.

Cette technique est tr�s souvent utilis�e pour acc�der byte par byte �
des structures complexes
------------------------------*/