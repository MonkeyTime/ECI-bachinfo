/*------------------------------
LANGAGE C - H. Schyns

Le�on 5 - Exercice 1
- Les pointeurs
- Les adresses
- Les contenus

Programme :
Mettre une valeur dans une variable
Lire son adresse
Stocker l'adresse dans un pointeur
Lire le contenu du pointeur
------------------------------*/
#include <conio.h>
#include <stdio.h>
void main (void)
{
 int ia;
 int *pp;
 clrscr();
                    /* stocker 18 dans ia */
 ia=18;           
                    /* afficher la valeur contenue dans ia */
 printf ("valeur de ia = %d\n", ia);
                    /* afficher l'adresse de la variable ia */     
 printf ("adresse de ia = %p\n", &ia);
                    /* mettre l'adresse de ia dans le pointeur pp */
 pp= &ia;
                    /* afficher l'adresse contenue dans le pointeur */     
 printf ("adresse stockee dans pp = %p\n", pp);
                    /* afficher le contenu de l'adresse qui se trouve                                       
                       dans le pointeur */     
 printf ("valeur contenue � l'adresse stockee dans pp = %d\n", *pp);
 getch();
}
/*------------------------------
Explications :
Un pointeur est une m�moire (variable) qui est pr�vue pour recevoir une
adresse m�moire. Un pointeur a toujours une taille de 4 bytes.

ia est une variable qui contient un entier
pp est une pointeur sur un entier (int *), autrement dit une variable
destin�e � recevoir l'adresse d'une variable de type entier
L'adresse de la variable est son emplacement en m�moire.
Elle est de la forme ssssssss:oooooooo o�
ssssssss est le segment (en gros, le num�ro de la page de m�moire RAM)
oooooooo est l'offset (en gros, la position sur la page)
& est l'op�rateur qui fournit l'adresse d'une variable.
variable : ia -> adresse &ia
Notez le format %p dans printf pour afficher une adresse
* est l'op�rateur qui fournit la valeur contenue dans la m�moire dont
l'adresse est dans le pointeur
pointeur : pp -> valeur stock�e � l'adresse contenue dans pp : *pp
Notez le format %d dans printf car on affiche maintenant le contenu qui
est un entier
------------------------------*/