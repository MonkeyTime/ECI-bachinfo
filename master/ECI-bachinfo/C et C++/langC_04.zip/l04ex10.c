/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 10
- Boucles for() imbriqu�es
- Algorithme de tri d'un tableaux
- Affichage semi-graphique

Programme
(identique au pr�c�dentdans le principe)
Demander � l'utilisateur le nombre d'�l�ments qu'il d�sire classer 
(<=NELEM)
Afficher une s�rie de cellules vides qui se remplissent au fur et � 
mesure que l'utilisateur introduit les chiffres.
Indiquer les cellules qui seront permut�es � chaque �tape du tri
Afficher la liste de cellules tri�es

------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define H_NELEM 15

void main(void)
{
 int vect[H_NELEM];
 int nval;
 int iswap, i, j, k;

 clrscr();
 printf ("Combien de nombres voulez-vous trier [3-%d] ? ",H_NELEM);
 scanf ("%d", &nval);
 if ((nval < 3) || (nval > H_NELEM))
    {
     printf ("Valeur non admise. Au revoir\n");
 	 exit(0);
    }
					/*- saisir et afficher la liste non tri�e -*/

 for (i=0; i<nval; i++)
     {
      printf("\nNombre [%2d] ? ", i+1);
	  scanf ("%d", &vect[i]);

      clrscr();		/*- effacer l'�cran avant d'afficher la bo�te -*/

      printf ("\nAvant :");
					/*- afficher la barre sup�rieure -*/
      printf ("\n+");
      for (k=0; k<nval; k++)
     	 printf ("----+");
					/*- afficher les valeurs -*/
      printf ("\n|");
      for (k=0; k<=i; k++)
           printf ("% 3d |",vect[k]);
					/*- afficher les cellules encore vides -*/
      for (; k<nval; k++)
           printf ("    |");
					/*- afficher la barre inf�rieure -*/
      printf ("\n+");
      for (k=0; k<nval; k++)
	   	 printf ("----+");
     }

					/*- trier la liste -*/

 for (i=0;i<nval-1; i++)
      for(j=i+1; j<nval; j++)
	  if (vect[j]<vect[i])
	     {
	      clrscr();	/*- effacer l'�cran avant d'afficher la bo�te -*/

		  printf ("\nPendant ([ENTER] pour continuer) :");
					/*- afficher la barre sup�rieure -*/
          printf ("\n+");
          for (k=0;k<nval;k++)
               if (k==i) printf (">>>>+");
			   else if (k==j) printf ("<<<<+");
			   else printf ("----+");
					/*- afficher les valeurs -*/
          printf("\n|");
          for (k=0;k<nval;k++)
              printf ("% 3d |",vect[k]);
					/*- afficher la barre inf�rieure -*/
          printf ("\n+");
          for (k=0;k<nval;k++)
         	 printf ("----+");
					/*- permuter les deux valeurs indiqu�es -*/
	      iswap=vect[i];
	      vect[i]=vect[j];
	      vect[j]=iswap;
		  getch();
	     }
				/*- afficher la liste tri�e -*/

 clrscr();		/*- effacer l'�cran avant d'afficher la bo�te -*/
 printf ("\nApr�s :");
				/*- afficher la barre sup�rieure -*/
 printf ("\n+");
 for (k=0;k<nval;k++)
   	  printf ("----+");
				/*- afficher les valeurs -*/
 printf("\n|");
 for (k=0;k<nval;k++)
     printf ("% 3d |",vect[k]);
				/*- afficher la barre inf�rieure -*/
 printf ("\n+");
 for (k=0;k<nval;k++)
	 printf ("----+");

 getch();
}

/*------------------------------
Explications :

if ((nval < 3) || (nval > H_NELEM))
Deux conditions () () r�unies par l'op�rateur logique "OU" (||). 
Elle se lit :
Si nval est inf�rieur � 3 OU si nval est sup�rieur � H_NELEM alors...

exit(0);
Provoque la sortie imm�diate du programme en prenant toutes les 
pr�cautions n�cessaires : lib�ration de la m�moire, fermeture des 
fichiers �ventuels, etc

Saisir et afficher la liste non tri�e
Noter la boucle ext�rieure du i et les boucles int�rieures sur k

Trier la liste
if (k==i) printf (">>>>+");
else if (k==j) printf ("<<<<+");
Si la cellule est celle d'un nombre qui doit changer de place, afficher
>>>> ou <<<< suivant que ce nombre va vers la fin ou vers le d�but du
vecteur

Notez que les trois s�quences d'affichage de la boite contenant les 
nombres sont pratiquement identiques Nous verrons que cette s�quence 
peut �tre transform�e en une routine.

------------------------------*/
