/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 6
- Les tableaux ou vecteurs
- Acc�s aux diff�rents �l�ments d'un vecteur

Programme
Demander un nombre r�el
Placer ce nombre dans le premier emplacement d'un tableau de NELEM 
�l�ments
Remplir le reste du tableau de telle mani�re que chaque �l�ment soit le 
double de l'�l�ment pr�c�dent
Afficher le r�sultat
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define NELEM 5

void main(void)
{
 float fvect[NELEM], a;
 int i;

 clrscr();
 printf ("Entrez un nombre r�el : ");
 scanf ("%f", &a);
 
 fvect[0]=a;
 for(i=1;i<NELEM;i++)
     fvect[i]=2.* fvect[i-1];
 
 for (i=0;i<NELEM;i++)
      printf("Vect[%1d] = %9.3f\n",i, fvect[i]);
}

/*------------------------------
Explications :

float fvect[NELEM];
Cette fois, il s'agit d'un vecteur de NELEM �l�ments de type r�el
(float)

fvect[0]=a;
Le premier �l�ment est rempli avec la valeur saisie dans la variable 
annexe "a"

for(i=1;i<NELEM;i++)
La liste des �l�ments suivants commence � 1 et non � 0

fvect[i]=2.* fvect[i-1];
Le calcul de l'indice i-1 ne modifie pas la valeur de i. Comme 
fvect[i-1] est un r�el et non un entier, on ne peut pas effectuer la 
multiplication par (fvect[i-1]<<1).

Notez aussi la pr�sence du point d�cimal apr�s le 2. Ceci indique � C 
que 2. doit �tre trait� comme un nombre r�el et non un entier. Si on 
avait �crit (ce qui est parfaitement valable)
fvect[i]=2 * fvect[i-1];
C transformerait chaque fois la valeur enti�re "2" en une valeur r�elle 
"2." avant d'effectuer l'op�ration, ce qui est une perte de temps.

ATTENTION,
On ne peut pas �crire
fvect[i]=2.* fvect[--i];
car --i modifie la valeur de i. On serait alors dans une boucle infinie 
dans laquelle on recomence sans cesse la m�me op�ration

------------------------------*/
