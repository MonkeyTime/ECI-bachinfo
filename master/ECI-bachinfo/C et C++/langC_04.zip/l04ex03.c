/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 3
- Les tableaux ou vecteurs

Programme
Cr�er un tableau de n entiers
Le remplir avec une suite DECROISSANTE de nombres 
(de 2 en 2 � partir de 60)

Puis afficher ces n nombres � la suite l'un de l'autre en les s�parant 
par un tiret :
60 - 58 - 56 - ...
------------------------------*/

#include <stdio.h>
#include <conio.h>

#define VECTSIZE 20

void main (void)
{
 int ivect[VECTSIZE];
 int i, istart;

 istart=60;
 for (i=0; i<VECTSIZE; i++)
     {
      ivect[i]=istart;
      istart-=2;
     }

 clrscr();
 for (i=0; i<VECTSIZE-1; i++)
      printf("%2d - ",ivect[i]);
      
 printf("%2d\n",ivect[VECTSIZE-1]);
}

/*------------------------------
Explications :

istart=60;
Le plus simple est de d�finir une variable qui va contenir la valeur � 
stocker et sur laquelle on va effectuer les calculs

for (i=0; i<VECTSIZE-1; i++)
Comme il y a un tiret entre chaque nombre, on a VECTSIZE nombres mais 
seulement VECTSIZE-1 tirets. Il faut donc traiter sp�cifiquement soit 
l'affichage du premier nombre, soit l'affichage du dernier.

------------------------------*/
