/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 8
- Boucles for() imbriqu�es
- Algorithme de tri d'un tableaux

Programme
Soit un vecteur de NELEM �l�ments entiers dans le d�sordre
Tri� les �l�ments en ordre croissant
Pr�senter la liste des �l�ments tri�s
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define H_NELEM 10

void main(void)
{
 int vect[H_NELEM]={3,7,2,5,8,9,6,10,-1,-5};
 int iswap;
 int i, j;

 clrscr();
				/*- afficher la liste non tri�e -*/

 printf ("Avant :\n|");
 for (i=0;i<H_NELEM;i++)
      printf (" %2d |",vect[i]);

				/*- trier la liste -*/

 for (i=0;i<H_NELEM-1; i++)
      for(j=i+1; j<H_NELEM; j++)
	  if (vect[j]<vect[i])
	     {
	      iswap=vect[i];
	      vect[i]=vect[j];
	      vect[j]=iswap;
	     }
				/*- afficher la liste tri�e -*/

 printf("\nApr�s :\n|");
 for (i=0;i<H_NELEM;i++)
      printf (" %2d |",vect[i]);
}

/*------------------------------
Explications :

Principe du tri
On prend le premier �l�ment de la liste comme r�f�rence
on le compare � tous les �l�ments qui suivent
chaque fois que l'un de ces �l�ments est plus petit que celui qui sert 
de r�f�rence on permute la r�f�rence et l'�l�ment trouv�
A ce stade, le premier �l�ment du vecteur contient la plus petite 
valeur.
On passe � l'�l�ment suivant et on recommence le processus.

int vect[H_NELEM]={3,7,2,5,8,9,6,10,-1,-5};
On peut initialiser un vecteur en iscrivant directement la liste de ses 
�l�ments dans une accolade. Les �l�ments sont s�par�s par des virgules. 
Il peut y avoir moins d'�l�ments dans la liste que ce qui est pr�vu par 
la taille du vecteur mais jamais plus.

for (i=0;i<H_NELEM-1; i++)
Inutile d'examiner le dernier �l�ment. Si les H_NELEM-1 premiers sont 
bien tri�s, le dernier sera forc�ment le plus grand.

for(j=i+1; j<H_NELEM; j++)
La premi�re comparaison porte sur l'�l�ment qui suit celui qu'on a pris 
comme r�f�rence. Ici, on examine la liste jusqu'au bout.

iswap=vect[i];
vect[i]=vect[j];
vect[j]=iswap;
Pour permuter deux valeurs, on a besoin d'une variable (iswap) qui sert 
de parking temporaire. En effet, si on �crit
vect[i]=vect[j];
vect[j]=vect[i];
on retrouve la m�me valeur dans les deux �l�ments.

Notons au passage que les instructions d'affichage de la liste brute et
de la liste tri�e sont rigoureusement identiques

------------------------------*/
