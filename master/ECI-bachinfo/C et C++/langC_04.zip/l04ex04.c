/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 4
- Les tableaux ou vecteurs
- Forme g�n�rale de l'instruction "for"

Programme
(identique au pr�c�dent)
Cr�er un tableau de n entiers
Le remplir avec une suite DECROISSANTE de nombres 
(de 2 en 2 � partir de 60)

Puis afficher ces n nombres � la suite l'un de l'autre en les s�parant 
par un tiret :
60 - 58 - 56 - ...
------------------------------*/

#include <stdio.h>
#include <conio.h>

#define VECTSIZE 20

void main (void)
{
 int ivect[VECTSIZE];
 int i, istart;

 for (i=0, istart=60; i<VECTSIZE; i++, istart-=2)
      ivect[i]=istart;

 clrscr();
 
 printf("%2d",ivect[0]);
 for (i=1; i<VECTSIZE; i++)
      printf(" - %2d",ivect[i]);
}

/*------------------------------
Explications :

for (i=0, istart=60; i<VECTSIZE; i++, istart-=2)
L'initialisation de la variable qui contient la valeur � stocker est 
effectu�e dans la zone d'initialisation de la boucle "for". Elle est 
s�par�e de l'initialisation de i par une virgule.
De m�me, la modification de cette variable est effectu�e dans la zone 
d'incr�mentation de la boucle "for". Elle est aussi s�par�e de 
l'incr�mentation de i par une virgule.
La forme g�n�rale de la boucle "for" est donc
for ( , , ,... ;  ; , , ,...)
Notez qu'il n'y a jamais qu"UN SEUL test de fin de boucle (qui peut �tre 
une condition complexe bourr�e de ET et de OU)

printf("%2d",ivect[0]);
Ici, on a choisi de traiter s�par�ment le premier �l�ment. Cette 
solution est un peu plus rapide que la pr�c�dente car dans la boucle
for (i=0; i<VECTSIZE-1; i++)
il y avait chaque fois un recalcul de l'expression VECTSIZE-1


------------------------------*/
