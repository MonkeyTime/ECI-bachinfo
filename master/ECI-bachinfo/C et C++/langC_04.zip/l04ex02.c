/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 2
- Les tableaux ou vecteurs
- Utilisation d'une directive #define

Programme
(identique au pr�c�dent)
Cr�er un tableau de n entiers
Le remplir avec les nombres de 1 � n
Puis afficher ces n nombres
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define VECTSIZE 20

void main (void)
{
 int p=415, ivect[VECTSIZE], k=365;
 int i;

 for (i=0; i<VECTSIZE; i++)
      ivect[i]=i+1;

 clrscr();
 for (i=0; i<VECTSIZE; i++)
      printf("element [%2d] = %d \n", i,ivect[i]);

 printf("element [%d] = %d \n",VECTSIZE, ivect[VECTSIZE]);
 printf("element [%d] = %d \n",-1, ivect[-1]);
}

/*------------------------------
Explications :

#define VECTSIZE 20
La dimension du vecteur intervient � plusieurs endroits dans ce 
programme :
- lors du dimensionnement,
- lors du remplissage,
- lors de la lecture et de l'affichage.
La directive #define permet l'emploi d'une variable symbolique. Lors de 
la compilation, le compilateur remplacera toutes les occurences de cette 
variable par la valeur qui lui a �t� donn�e en t�te de module

C ne permet pas de dimensionner un vecteur � l'aide d'une variable (du 
moins, pas de cette mani�re) :
void main (void)
{
 int vsize = 20;
 int ivect[vsize];
 int i;
 :
 :
}
m�me si vsize est connu lors de la compilaton, comme c'est le cas ici o� 
on sait d�s la premi�re ligne que vsize vaut 20.

int p=415, ivect[VECTSIZE], k=365;
On d�finit une variable enti�re p � laquelle on donne une valeur, juste 
avant de d�finir le vecteur. De m�me, on d�finit une variable k qui 
occupera l'espace m�moire situ� juste apr�s le vecteur et on lui 
attribue la valeur 365. On verra que c'est cette valeur qui est affich�e 
� la derni�re ligne, lorsque l'on d�passe la fin du vecteur.

printf("element [VECTSIZE] = %d \n",ivect[VECTSIZE]);
Dans l'instruction �crite de cette mani�re, le premier VECTSIZE ne sera 
pas remplac� lors de la compilation car il appara�t dans une cha�ne de 
caract�res (d�limit�e par "..."). Par contre, dans l'instruction 
printf("element [%d] = %d \n",VECTSIZE, ivect[VECTSIZE]);
VECTSIZE appara�t en dehors de la cha�ne de caract�res et sa valeur sera 
correctement substitu�e. Reste � la faire appara�tre dans le texte 
affich� � l'aide d'un format %d.

printf("element [%d] = %d \n",-1, ivect[-1]);
C ne se pose aucune question quant � la validit� des indices des 
vecteurs. Il est permis d'acc�der � la m�moire situ�e AVANT l'origine du 
vecteur... � ses propres risques et p�rils! Mais dans certains cas, cela 
peut se justifier.

------------------------------*/
