/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 7
- Les tableaux ou vecteurs
- Optimisation des acc�s au vecteur dans la boucle 

Programme
(identique au pr�c�dent)
Demander un nombre r�el
Placer ce nombre dans le premier emplacement d'un tableau de NELEM 
�l�ments
Remplir le reste du tableau de telle mani�re que chaque �l�ment soit le 
double de l'�l�ment pr�c�dent
Afficher le r�sultat
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define NELEM 5

void main(void)
{
 float fvect[NELEM];
 int i, iprev;

 clrscr();
 printf ("Entrez un nombre r�el : ");
 scanf ("%f", &fvect[0]);
 
 for(i=1, iprev=0; i<NELEM; iprev=i++)
     fvect[i]=2.* fvect[iprev];
 
 for (i=0;i<NELEM;i++)
      printf("Vect[%1d] = %9.3f\n",i, fvect[i]);
}

/*------------------------------
Explications :

scanf ("%f", &fvect[0]);
Si &a est l'adresse de a, alors &fvect[0] est l'adresse de fvect[0].
Autant fournir directement l'adresse de la variable correcte � scanf ce 
qui �vite l'emploi d'une variable interm�diaire. Nous verrons plus loin 
que &fvect[0] �quivaut � fvect. On pourrait �crire 
scanf ("%f", fvect); 
Cependant, le compilateur de Borland a un bug qui g�n�re une erreur dans 
ce cas pr�cis.

for(i=1, iprev=0; i<NELEM; iprev=i++)
Dans l'exemple pr�c�dent, la boucle imposait chaque fois le recalcul de 
i-1. En utilisant une variable suppl�mentaire (iprev) initialis�e � 0,
on �vite ce probl�me. Dans l'expression
iprev=i++
on stocke la valeur actuelle de i dans iprev, ENSUITE on incr�mente i, 
PUIS on entre dans une nouvelle it�ration. D�s lors, iprev contient 
toujours la valeur qu'avait i � l'it�ration pr�c�dente.

Cette version est donc plus rapide que la pr�c�dente.

Par contre,
for(i=1, iprev=0; i<NELEM; )
     fvect[i]=2.* fvect[iprev=i++];
est un bloc licite mais son r�sultat est erronn� et impr�visible car au 
moment o� on affecte iprev, la valeur de i est la m�me � gauche 
et � droite du signe =.

------------------------------*/
