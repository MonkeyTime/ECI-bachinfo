/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 5
- Les tableaux ou vecteurs
- Ce qu'il ne faut pas faire...

Programme
(identique au pr�c�dent)
Cr�er un tableau de n entiers
Le remplir avec une suite DECROISSANTE de nombres 
(de 2 en 2 � partir de 60)

Puis afficher ces n nombres � la suite l'un de l'autre en les s�parant 
par un tiret :
60 - 58 - 56 - ...
------------------------------*/

#include <stdio.h>
#include <conio.h>

#define VECTSIZE 20

void main (void)
{
 int ivect[VECTSIZE];
 int i;

 for (i=0; i<VECTSIZE; i++)
      ivect[i]=60-2*i;

 clrscr();
 
 printf("%2d",ivect[0]);
 for (i=1; i<VECTSIZE; i++)
      printf(" - %2d",ivect[i]);
}

/*------------------------------
Explications :

for (i=0; i<VECTSIZE; i++)
      ivect[i]=60-2*i;

Cette forme donne exactement le m�me r�sultat que la forme expos�e dans 
le probl�me pr�c�dent. Elle est cependant beaucoup moins performante. 
car chaque passage dans la boucle demande une multiplication, laquelle 
prend environ 10 fois plus de temps qu'une addition ou une soustraction.

On aurait pu � la rigueur �crire
ivect[i]=60 - (i<<1);
ce qui est d�j� nettement meilleur quoique toujours moins performant

------------------------------*/
