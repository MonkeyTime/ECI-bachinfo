/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 9
- Boucles for() imbriqu�es
- Algorithme de tri d'un tableaux

Programme
Soit un vecteur de NELEM �l�ments entiers dans le d�sordre
Tri� les �l�ments en ordre croissant
Pr�senter la liste des �l�ments tri�s
------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define H_NELEM 20

void main(void)
{
 int vect[H_NELEM];
 int nval;
 int iswap, i, j;

 clrscr();
 printf ("Combien de nombres voulez-vous trier [3-%d] ? ",H_NELEM);
 scanf ("%d", &nval);
 if ((nval < 3) || (nval > H_NELEM))
    {
     printf ("Valeur non admise. Au revoir\n");
 	 exit(0);
    }
 
 for (i=0; i<nval; i++)
     {
      printf("Nombre [%2d] ? ", i+1);
	  scanf ("%d", &vect[i]);
     }

				/*- afficher la liste non tri�e -*/

 printf ("\nAvant :");
 printf ("\n+");
 for (i=0;i<nval;i++)
	 printf ("----+");

 printf ("\n|");
 for (i=0;i<nval;i++)
      printf ("% 3d |",vect[i]);

 printf ("\n+");
 for (i=0;i<nval;i++)
	 printf ("----+");
				/*- trier la liste -*/

 for (i=0;i<nval-1; i++)
      for(j=i+1; j<nval; j++)
	  if (vect[j]<vect[i])
	     {
	      iswap=vect[i];
	      vect[i]=vect[j];
	      vect[j]=iswap;
	     }
				/*- afficher la liste tri�e -*/

 printf ("\nApr�s :");
 printf ("\n+");
 for (i=0;i<nval;i++)
	 printf ("----+");

 printf ("\n|");
 for (i=0;i<nval;i++)
      printf ("% 3d |",vect[i]);

 printf ("\n+");
 for (i=0;i<nval;i++)
	 printf ("----+");
}


/*------------------------------
Explications :

M�me probl�me que pr�c�demment, mais cette fois, les donn�es dont 
pr�sent�es dans des cellules.
Le bloc d'instructions qui effectue le dessin des cellules est le m�me
dans la pr�sentation initiale et finale du vecteur
------------------------------*/
