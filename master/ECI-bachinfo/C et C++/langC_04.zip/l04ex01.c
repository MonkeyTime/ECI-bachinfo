/*------------------------------
LANGAGE C - H. Schyns

Le�on 4 - Exercice 1
- Les tableaux ou vecteurs

Programme
Cr�er un tableau de 20 nombres entiers
Le remplir avec les nombres de 1 � 20
Puis afficher ces 20 nombres
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ivect[20];
 int i;

 for (i=0; i<20; i++)
      ivect[i]=i+1;

 clrscr();
 for (i=0; i<20; i++)
      printf("element [%2d] = %d \n", i,ivect[i]);

 printf("element [20] = %d \n",ivect[20]);
}

/*------------------------------
Explications :

int ivect[20];
D�finit un tableau (aussi appel� vecteur) de 20 �l�ments de type "int". 
ATTENTION : Ces �l�ments sont num�rot�s de 0 � 19 et non de 1 � 20.

for (i=0; i<20; i++)
La boucle commence � l'�l�ment 0 (i=0) et s'arr�te avant d'arriver � 
l'�l�ment 20 (i<20).

ivect[i]
D�signe le i_�me �l�ment du tableau. Le premier �l�ment est i[0]. Dans 
le cas de l'exemple, le dernier est i[19].

printf("element [%2d]...);
Les nombres entiers peuvent aussi �tre format�s. Ici, %2d pr�cise que 
l'affichage doit toujours occuper 2 positions, m�me si le nombre n'a 
qu'un seul chiffre.

printf("element [20] = %d ",ivect[20]);
Bien que le vecteur n'ait que 20 composantes num�rot�es de 0 � 19, C 
n'interdit absolument pas d'aller lire ou �crire au-del� de la fin du 
vecteur. Une instruction telle que ivect[3580]=0 ne g�n�rera aucune 
erreur (sauf si on a sp�cifiquement demand� la d�ctection de telles 
erreurs, et encore!). En lecture, le seul probl�me est que l'on ne sait 
pas ce qu'on va lire �tant donn� que cet emplacememnt en m�moire peut 
�tre occup� par une autre variable. En �criture, les cons�quences 
peuvent �tre catastrophiques.
------------------------------*/
