/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 1
- La boucle FOR(;;)

Programme
Afficher les nombres de 0 � 9
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int i;
 clrscr();
 for (i=0; i<10; i=i+1)
     {
      printf ("boucle %d\n",i);
     }
 printf ("valeur de i : %d\n", i);
}

/*------------------------------
Explications :

for (i=0; i<10; i=i+1)
La d�finition de la boucle for comprend trois zones s�par�es par des 
points-virgules : la zone d'initialisation, qui est ex�cut�e avant le 
premier passage; la zone de test, qui est �valu�e avant d'entamer un 
passage; la zone d'incr�mentation, qui est ex�cut�e � la fin d'un 
passage.

Les instructions de la boucle proprement dite sont celles du paragraphe 
d�limit� par les accolades {} qui suivent imm�diatement l'instruction 
for (comme dans le cas du if..else, les accolades ne sont n�cessaires 
que s'il y a plus d'une instruction dans la boucle)

Notez qu'il n'y a pas de point-virgule apr�s la ligne for(;;)

printf ("valeur de i : %d\n", i);
A la sortie de la boucle, la valeur de i est la premi�re valeur qui 
invalide le test (10 dans le cas pr�sent) 
------------------------------*/
