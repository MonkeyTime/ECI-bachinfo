/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 6
- La boucle DO {} WHILE()

Programme
Lire un nombre ind�termin� a priori de valeurs enti�res
Calculer leur nombre, la somme, le minimum et le maximum

------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int inbr, somme, vmax, vmin, nval;

 nval = somme = 0;
 do {
	 clrscr();
 	 printf ("introduisez un nombre positif (%d) [0 pour terminer] : ",nval+1);
 	 scanf ("%d", &inbr);

	 if (inbr > 0)
		{
      	 somme+=inbr;
      	 if (nval++)
	 	 	{
	  	  	 if (inbr>vmax) vmax=inbr;
	  	  	 else if (inbr<vmin) vmin=inbr;
	     	}
      	 else
	 		vmax=vmin=inbr;
        }
    } while (inbr > 0);

 printf ("vous avez introduit %d nombres\n", nval);
 printf ("le plus grand nombre est : %d\n", vmax);
 printf ("le plus petit nombre est : %d\n", vmin);
 printf ("la somme vaut            : %d\n", somme);
 getch();
}

/*------------------------------
Explications :

do..while (inbr > 0);
faire...tant que

Le test �tant plac� en fin de boucle, celle---ci est effectu�e au moins 
une fois. Or, si l'utilisateur a introduit 0, il faut arr�ter le 
traitement d'o� l'usage fort peu �l�gant d'un test "if" � l'int�rieur de 
la boucle. Le test du "if" est d'ailleurs exactement celui du "while", 
ce qui est encore plus in�l�gant.

Par contre, le bloc de questions n'est pr�sent� qu'une seule fois.

Notez que, cette fois, il y a un point-virgule apr�s le test final!
------------------------------*/
