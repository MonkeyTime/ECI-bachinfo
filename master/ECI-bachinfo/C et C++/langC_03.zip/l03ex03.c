/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 3
- La boucle FOR... (autre forme)

Programme
Afficher les nombres de 0 � H_IMAX-1 ou de 1 � H_IMAX
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define H_IMAX 10

void main (void)
{
 int i;
 clrscr();
 i=0;
 for (; i<H_IMAX;)
      printf ("boucle %d\n",i++);
     
 printf ("valeur de i : %d\n", i);
}

/*------------------------------
Explications :

i=0;
for (; i<H_IMAX;)
Il est permis d'effectuer l'initialisation de la variable de boucle en 
dehors de l'instruction for. N�anmoins, dans l'expression for (;;) on 
doit garder les deux points-virgules qui servent de d�limiteurs aux 
trois zones, m�me si celles-ci sont vides.

printf ("boucle %d\n",i++); 
L'incr�mentation i++ est effectu�e dans l'instruction printf. 

i++ est une post-incr�mentation : on utilise la 
valeur de i pour l'instruction printf et APRES, on incr�mente i.

il existe aussi une instruction de pr�-incr�mentation ++i : on 
incr�mente i AVANT et puis on utilise la valeur incr�ment�e dans 
l'expression.  

Testez les deux variantes : dans un cas la boucle est num�rot�e 0..9; 
dans l'autre 1..10. Dans les deux cas la valeur de i � la sortie vaut 
10.
------------------------------*/
