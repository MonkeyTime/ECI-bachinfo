/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 2
- La boucle FOR... (version condens�e et param�tr�e)

Programme
Afficher les nombres de 1 � H_IMAX
------------------------------*/
#include <stdio.h>
#include <conio.h>

#define H_IMAX 10

void main (void)
{
 int i;
 clrscr();
 for (i=0; i<H_IMAX; i++)
      printf ("boucle %d\n",i);
 printf ("valeur de i : %d\n", i);
}

/*------------------------------
Explications :

#define H_IMAX 10
Il est g�n�ralement peu recommand� de coder "en dur" les limites des 
boucles "for".  En cas de modification du programme - par exemple si on 
veut ex�cuter la boucle 20 fois au lieu de 10 - il faut rechercher 
toutes les occurences de la valeur et �tre certain de n'en oublier 
aucune. Ici, �videmment, le cas est simplissime mais les choses peuvent 
se compliquer singuli�rement dans un programme d'un millier de lignes.

La solution consiste � utiliser une "directive de compilation" 
(#define). Cette instruction demande au compilateur de remplacer la 
valeur symbolique H_IMAX par la valeur 10 chaque fois qu'il la 
rencontrera dans le texte.

Si on d�cide d'ex�cuter 20 fois la boucle, il suffira de changer la 
valeur de H_IMAX dans la ligne #define situ�e en d�but de programme.
Notez l'absence de signe = dans l'expression #define

i++ 
Nous avons d�j� vu qu'un instruction du type i=i+1 pouvait s'�crire sous 
la forme condens�e i+=1. Dans le cas particulier de l'incr�mentation 
simple (addition d'une unit�) C propose une forme encore plus condens�e 
et encore plus rapide : i++. Autrement dit :
i=i+1 �quivaut � i+=1 �quivaut � i++

Notez que les accolades de la boucle ont �t� supprim�es car la boucle ne 
contient qu'une seule instruction.

------------------------------*/
