/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 5
- La boucle WHILE{}

Programme
Lire un nombre ind�termin� a priori de valeurs enti�res
Calculer leur nombre, la somme, le minimum et le maximum

------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int inbr, somme, vmax, vmin, nval;

 nval = somme = 0;
 clrscr();
 printf ("introduisez un nombre positif (%d) [0 pour terminer] : ",nval+1);
 scanf ("%d", &inbr);
 while (inbr > 0)
       {
      	somme+=inbr;
      	if (nval++)
	 	 	{
	  	  	 if (inbr>vmax) vmax=inbr;
	  	  	 else if (inbr<vmin) vmin=inbr;
	     	}
      	else
	 		vmax=vmin=inbr;

		clrscr();
		printf ("introduisez un nombre positif (%d) [0 pour terminer] : ",nval+1);
 		scanf ("%d", &inbr);
       }

 printf ("vous avez introduit %d nombres\n", nval);
 printf ("le plus grand nombre est : %d\n", vmax);
 printf ("le plus petit nombre est : %d\n", vmin);
 printf ("la somme vaut            : %d\n", somme);
 getch();
}

/*------------------------------
Explications :

while (inbr > 0) tant que... 
Le traitement dans les accolades est r�p�t� tant que l'utilisateur 
fournit un nombre positif. Le nombre de fois que la boucle est parcourue 
n'est pas connu a priori.

Le test �tant plac� en d�but de boucle, il se peut que la boucle ne soit 
jamais effectu�e.

Notez qu'il n'y a pas de point-virgule apr�s le test sinon on aurait une 
boucle infinie!

Remarquez que la s�quence d'instructions avant d'entrer dans la boucle 
est exactement la m�me que celle pos�e en fin de boucle, avant de 
recommencer un passage
------------------------------*/
