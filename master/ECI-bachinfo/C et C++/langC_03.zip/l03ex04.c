/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 4
- La boucle FOR... 
- Les instructions if imbriqu�es

Programme
Lire un nombre d�termin� H_IMAX de valeurs enti�res
Calculer la somme, rechercher le minimum et le maximum

------------------------------*/
#include <stdio.h>
#include <conio.h>

#define H_IMAX 10

void main (void)
{
 int i;
 int inbr, somme, vmax, vmin;

 somme = 0;
 for (i=0; i<H_IMAX; i++)
     {
      clrscr();
      printf ("introduisez le nombre (%d)\n",i+1);
      scanf ("%d", &inbr);
      somme+=inbr;
      if (i)
	 	 {
	  	  if (inbr>vmax) vmax=inbr;
	  	  else if (inbr<vmin) vmin=inbr;
	     }
      else
	 	vmax=vmin=inbr;
     }
 printf ("le plus grand nombre est : %d\n", vmax);
 printf ("le plus petit nombre est : %d\n", vmin);
 printf ("la somme vaut            : %d\n", somme);
 getch()
}

/*------------------------------
Explications :

somme = 0;
On utilise une variable sp�ciale pour faire la somme. Cette variable est 
initialis�e � 0 avant de commencer;

printf ("introduisez le nombre (%d)\n",i+1);
L'instruction i+1 est effectu�e avant d'assembler la cha�ne � afficher.
Cette intruction ne modifie pas la valeur de i;

somme+=inbr;
Affectation compos�e, d�j� vue dans un autre exemple. Elle revient �
somme = somme + inbr;

if (i)
Nous avons vu que le test entre parenth�se doit renvoyer une valeur VRAI 
(non z�ro) ou FAUX (z�ro).
Les instructions
(i!=0) (VRAI donc non z�ro si i=1,2,...)
et
(i) (non z�ro donc VRAI si i=1,2,...) 
sont parfaitement �quivalentes mais la seconde �conomise une op�ration 
de comparaison

vmax=vmin=inbr;
C permet d'initialiser plusieurs variables en cascade :
a = b = c = d = 1;
(toutes les variables de la liste prennent la valeur 1)
par contre
a = b+1 = c+1 = d+1 = 1;
est interdit (on n'a pas d=1, c=2, b=3, a=1)
mais on pourrait �crire
a = (b = (c = (d=1) + 1) + 1) + 1

------------------------------*/
