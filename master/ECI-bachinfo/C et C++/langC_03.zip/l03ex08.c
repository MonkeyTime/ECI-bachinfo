/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 8
- boucles DO {} WHILE() imbriqu�es

Programme
Calcul de la racine carr� par l'algorithme de Newton :
Soit un nombre N (p.ex. 5.) dont on d�sire calculer la racine carr�e.
On prend une valeur quelconque R1 comme valeur approch�e (p.ex. 2.)
On trouve une meilleure valeur approch�e R2 = (R1 + N/R1)/2.
p.ex. R2 = (2.+5./2.)/2. = 2.125
On peut recommencer le processus autant de fois qu'on le d�sire en 
partant de l'estimation pr�c�dente.
p.ex. R1 = 2.125
      R2 = (2.125 + 5./2.125)/2 = 2.239
La nouvelle estimation est toujours meilleure (racine de 5 = 2.2361)
On arr�te le processus quand deux it�rations successives n'�voluent plus

------------------------------*/
#include <stdio.h>
#include <conio.h>
#include <math.h>

#define MY_PREC 0.00001

void main (void)
{
 double xval, xestim1, xestim2, prec;
 int niter;
 char crep;

 do {											/* do 1 */
     do {										/* do 2 */	
         clrscr();
     	 printf("Introduisez le nombre dont vous voulez la racine carr�e (>0) : ");
    	 scanf ("%lf",&xval);
        }while (xval <= 0.);					/* while du do 2 */
    
     niter = 0;
     xestim2 = 1.;
     do {										/* do 3 */
         xestim1 = xestim2;
         xestim2 = (xestim1 + xval/xestim1)/2.;
		 niter++;	
    	 prec = fabs(xestim2-xestim1)/xestim2;
        }while (prec > MY_PREC);				/* while du do 3 */
    
     printf("La racine carr�e de %.8lf est %.8lf (%d iterations)\n", xval, xestim2, niter);
     printf("Autre racine (O/N) ? ");
	 crep = getch();
    } while ((crep == 'o') || (crep == 'O'));	/* while du do 1 */

 printf ("\nMerci et au revoir !");
}

/*------------------------------
Explications :

#include <math.h>
math.h est la biblioth�que qui contient les fonctions math�matiques 
telles que dabs (valeur absolue)

do {1}
boucle sur la question "Autre racine ?"

do {2}
r�p�te la question tant qu'on donne un nombre non valide (<=0)

do {3}
algorithme proprement dit

xestim1 = xestim2;
On utilise la valeur obtenu � l'it�ration pr�c�dente comme valeur
initiale de l'it�ration que l'on recommence.

fabs(xestim2-xestim1)
fabs donne la valeur absolue de la diff�rence (la valeur absolue d'un
nombre est ce nombre ramen� du c�t� positif (fabs(+3)=+3; fabs(-3)=+3).
Comme il n'est pas certain que xestim2 soit plus grand que xestim1,
la diff�rence pourrait �tre aussi bien positive que n�gative ce qui pose
un probl�me par rapport au test > 0.00001
p.ex. 5-4 > 0.00001 (VRAI) mais 4-5 > 0.00001 (FAUX) or, dans les deux
cas, il faut continuer le calcul

prec = fabs(xestim2-xestim1)/xestim2;
on obtient la pr�cision relative,plus significative que la pr�cision 
absolue
p.ex.: 5-4 = 1 (pr�cision absolue = � une unit� pr�s)
      (5-4)/5=0.20 (pr�cision relative = � 20% pr�s)
Dans le cas pr�sent, la racine carr�e est fournie avec 5 chiffres 
significatifs.

------------------------------*/
