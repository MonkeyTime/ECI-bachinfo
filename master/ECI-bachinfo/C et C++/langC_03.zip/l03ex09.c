/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 9
- boucles DO {} WHILE() et WHILE(){} imbriqu�es.

Programme
Calcul de la racine carr� par l'algorithme de Newton :

------------------------------*/
#include <stdio.h>
#include <conio.h>
#include <math.h>

#define MY_PREC 0.00001

void main (void)
{
 double xval, xestim1, xestim2, prec;
 int niter;
 char crep;

 do {											/* do 1 */
     do {										/* do 2 */	
         clrscr();
     	 printf("Introduisez le nombre dont vous voulez la racine carr�e (>0) : ");
    	 scanf ("%lf",&xval);
        }while (xval <= 0.);					/* while du do 2 */
    
     niter = 0;
     xestim2 = 1.;
 	 while (xval > (xestim2+2)*xestim2)
			xestim2 *= 2.;
     
     do {										/* do 3 */
         xestim1 = xestim2;
         xestim2 = (xestim1 + xval/xestim1)*0.5;
		 niter++;	
    	 prec = fabs(xestim2-xestim1)/xestim2;
        }while (prec > MY_PREC);				/* while du do 3 */
    
     printf("La racine carr�e de %.8lf est %.8lf (%d iterations)\n", xval, xestim2, niter);
     printf("Autre racine (O/N) ? ");
	 crep = getch();
    } while ((crep == 'o') || (crep == 'O'));	/* while du do 1 */

 printf ("\nMerci et au revoir !");
}

/*------------------------------
Explications :

while (xval > (xestim2+2)*xestim2)
	   xestim2 *= 2.;
Cette petite boucle permet d'obtenir rapidement et � peu de frais une
meilleure valeur de d�part que xestim2=1.
p.ex : xval = 1000 => xestim2 = 1 > 2 > 4 > 8 > 16 > 32

xestim2 = (xestim1 + xval/xestim1)*0.5;
La multiplication de nombres r�els est beaucoup plus rapide que la 
division. D�s lors, multiplier par 0.5 est plus rapide que diviser par 2.
------------------------------*/
