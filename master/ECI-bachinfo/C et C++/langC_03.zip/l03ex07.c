/*------------------------------
LANGAGE C - H. Schyns

Le�on 3 - Exercice 7
- La boucle DO {} WHILE()
- l'instruction "break"

Programme
Lire un nombre ind�termin� a priori de valeurs enti�res
Calculer leur nombre, la somme, le minimum et le maximum

------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int inbr, somme, vmax, vmin, nval;

 nval = somme = 0;
 do {
	 clrscr();
 	 printf ("introduisez un nombre positif (%d) [0 pour terminer] : ",nval+1);
 	 scanf ("%d", &inbr);
	 if (inbr <= 0) break;

  	 somme+=inbr;
  	 if (nval++)
 	 	{
  	  	 if (inbr>vmax) vmax=inbr;
  	  	 else if (inbr<vmin) vmin=inbr;
     	}
  	 else
 		vmax=vmin=inbr;

    } while (1);

 printf ("vous avez introduit %d nombres\n", nval);
 printf ("le plus grand nombre est : %d\n", vmax);
 printf ("le plus petit nombre est : %d\n", vmin);
 printf ("la somme vaut            : %d\n", somme);
 getch();
}

/*------------------------------
Explications :

do..while (1);
faire...tant que
Le test �tant plac� en fin de boucle, celle-ci est effectu�e au moins 
une fois. Si l'utilisateur a introduit 0, le traitement de la boucle est 
arret� par l'instruction "break" qui provoque un saut � l'instruction 
qui suit l'accolade finale du "while".

Puisque la sortie est effectu�e en milieu de boucle, le while doit 
toujours provoquer un retour vers le "do". D'o� l'instruction while(1) 
qui, par d�finition, est toujours VRAI.
------------------------------*/
