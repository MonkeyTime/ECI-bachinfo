/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique
- R�allocation

Programme :

Phase 4
- definir a taille lors de l'execution
- remplacer for par do...while

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */
 int   i;
 unsigned int vsize;	/* variable qui definit la taille du vecteur  */
 char  crep;			/* pour stocker la reponse a une question     */


 clrscr();

						/*---definition de la taille--*/

 printf ("Combien de nombres max voulez-vous introduire ? ");
 scanf  ("%d", &vsize);
 if (vsize < 1) return;


						/*---------allocation---------*/

 fvect = (float *) malloc (vsize * sizeof(float));

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire %d nombres\n", vsize);
 i=0;
 do
	 {
	  printf ("\nNombre [%2d] : ", i+1);
	  scanf("%f", &ftrav);
	  fvect[i++]=ftrav;

						/*---- suite de la saisie ?---*/
	  crep = 'n';
	  if (i<vsize)
		 {
		  printf ("On continue [o/n] ? ");
		  crep = getche();
		 }

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:


On a remplace la boucle for par une boucle while
ce qui permet a l'utilisateur de sortir avant d'avoir rempli
toutes les valeurs

Par contre, il ne peut pas introduire plus de valeurs que
ce qu'il avait decide au depart:

	crep = 'n';
	if (i<vsize)
	   {
		printf ("On continue [o/n] ? ");
		crep = getche();
	   }

La question n'est pos�e que s'il reste de la place dans le
vecteur.

------------------------------*/
