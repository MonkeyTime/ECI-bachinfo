/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique
- R�allocation

Programme :

Phase 8
- V�rification de l'allocation

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */

 int   vsize;			/* la taille du vecteur  					  */
 int   idx;				/* index qui d�finit le niveau de remplissage */
 int   incr;			/* incrementation de la taille du vecteur     */

 char  crep;			/* pour stocker la reponse a une question     */


 clrscr();
						/*---definition de la taille--*/

 fvect =  0;            /* le pointeur ne pointe sur RIEN             */
 vsize =  0;			/* le vecteur ne contient AUCUNE cellule      */
 idx   = -1;			/* il n'y a rien dans le vecteur			  */
 incr  =  3;			/* ajouter les cellules par paquets de incr   */

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire autant de nombres que vous voulez\n");

 do
	 {
							/* on demande un nombre */
	  printf ("\nNombre [%2d] : ", idx+2);
	  scanf("%f", &ftrav);

							/* d�bordement ?        */
	  if (idx >= vsize-1)
		 {					/* oui, faire de la place et ajouter */
		  vsize+=incr;
		  fvect = (float *) realloc (fvect, vsize * sizeof(float));
         
          if (fvect == 0)   /* echec ?              */
             {
              printf ("Memoire insuffisante !\Arret du  programme");
              getch();
              return;
             }

		  printf("\nOn a ajoute %d cellules"
				 "\nIl y en a %d en tout\n",
					incr, vsize);
		 }

	  idx++;
	  fvect[idx]=ftrav;

      printf ("%d cellules sont occupees\n", idx+1);

						/*---- suite de la saisie ?---*/

	  printf ("On continue [o/n] ? ");
	  crep = getche();

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

Le systeme d'exploitation n'est pas toujours en mesure d'allouer la
memoire qui est demandee par un programme :

- le programme demande plus de memoire que ce qui est install� sur la
  machine
- d'autres processus ont d�j� r�serv� plusieurs pages de m�moire et il
  n'en reste plus assez pour satisfaire la demande

L'appel � malloc ou a realloc ne se termine pas toujours par un succes.
En cas d'�chec, malloc et realloc renvoient une adresse nulle.

    fvect = (float *) realloc (fvect, vsize * sizeof(float));

Apr�s l'appel � malloc ou realloc, il faut donc tester si l'adresse est
valide (non nulle) ou si l'allocation a �chou� (nulle)

    if (fvect == 0)   // echec ?             

ou, plus simplement

    if (!fvect)       // echec ?             

Dans ce cas, il faut soit avertir l'utilisateur et interrompre le
programme (ce qui est fait ici de mani�re assez brutale) soit traiter
l'erreur pour faire le minimum de degats.

------------------------------*/
