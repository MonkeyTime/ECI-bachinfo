/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique
- R�allocation

Programme :

Phase 3
- definir a taille lors de l'execution

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */
 int   i;
 unsigned int vsize;	/* variable qui definit la taille du vecteur  */


 clrscr();

						/*---definition de la taille--*/

 printf ("Combien de nombres voulez-vous introduire ? ");
 scanf  ("%d", &vsize);
 if (vsize < 1) return;

						/*---------allocation---------*/

 fvect = (float *) malloc (vsize * sizeof(float));

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous devez introduire %d nombres\n", vsize);
 for (i=0; i<vsize; ++i)
	 {
	  printf ("Nombre [%2d] : ", i+1);
	  scanf("%f", &ftrav);
	  fvect[i]=ftrav;
	 }

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

L'allocation dynamique permet de definir la taille d'un vecteur
au moment de l'execution.

Le vecteur reserve convient toujours exactement aux besoins, il
n'y a pas de gaspillage ni de penurie.

Lors d'une execution a l'autre, la taille du vecteur peut varier
SANS qu'il soit besoin de recompiler le programme.

Ici, on a remplace

	la constante VSIZE

par

	une variable vsize	(en minuscule)

La valeur de cette variable est definie au moment de l'execution.

	scanf  ("%d", &vsize);

Elle sert a definir exactement la taille du vecteur

	fvect = (float *) malloc (vsize * sizeof(float));

On prend quand meme la peine de verifier que la taille est
strictement positive

 if (vsize < 1) return;

------------------------------*/
