/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 1
- Allocation dynamique
- R�allocation

Programme :

phase 1
- Mettre une s�rie de valeurs dans un vecteur statique

------------------------------*/

#include <conio.h>
#include <stdio.h>

#define VSIZE 15

void main (void)
{
 float fvect [VSIZE];	/* vecteur dans lequel on stocke les nombres */
 float ftrav;           /* variable de transfert                     */
 int   i;

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous devez introduire %d nombres\n", VSIZE);
 for (i=0; i<VSIZE; ++i)
	 {
	  printf ("Nombre [%2d] : ", i+1);
	  scanf("%f", &ftrav);
	  fvect[i]=ftrav;
	 }
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

On retrouve un exercice fait pr�c�demment
Le vecteur est dimensionn� par lors de la compilation
Il n'est pas possible de modifier la taille sans recompiler
le programme.

------------------------------*/
