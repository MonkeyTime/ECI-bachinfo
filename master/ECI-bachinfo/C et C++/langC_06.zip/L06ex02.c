/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 2
- Allocation dynamique
- R�allocation

Programme :

Phase 2
- remplacer l'allocation statique par une dynamique

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

#define VSIZE 15

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */
 int   i;

						/*---------allocation---------*/

 fvect = (float *) malloc (VSIZE * sizeof(float));

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous devez introduire %d nombres\n", VSIZE);
 for (i=0; i<VSIZE; ++i)
	 {
	  printf ("Nombre [%2d] : ", i+1);
	  scanf("%f", &ftrav);
	  fvect[i]=ftrav;
	 }

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

Le vecteur

	float fvect[VSIZE]

est remplac� par un pointeur sur float

	float *fvect;

Un pointeur est une variable qui re�oit une adresse.
C'est une sorte de boite aux lettres.
A ce stade du programme on n'a defini que la boite aux lettres
mais pas la maison qui est derriere.
Autrement dit, IL N'EXISTE AUCUN ESPACE DE STOCKAGE

L'espace de stockage est defini par la fonction malloc (memory
allocation)

Par exemple

	malloc (4);

alloue (reserve) 4 bytes de m�moire preleves dans la "heap".
La demande est adressee au systeme d'exploitation.

	malloc ( sizeof(float) );

alloue (reserve) le nombre de bytes necessaires pour stocker une
variable de type float.

	malloc ( 10 * sizeof(float) );

alloue (reserve) le nombre de bytes necessaires pour stocker dix
variables de type float.

	malloc ( VSIZE * sizeof(float) );

alloue (reserve) le nombre de bytes necessaires pour stocker le
nombre de variables de type float d�fini par VSIZE

malloc renvoie l'adresse de cette zone memoire. L'adresse est stockee
dans un pointeur comme il se doit

	fvect = malloc ( VSIZE * sizeof(float) );

On doit garder l'adresse pour pouvoir acceder a la memoire.

	fvect = (float *) malloc ( VSIZE * sizeof(float) );

Avant de stocker l'adresse, on fait un "cast". Ainsi, la suite
du programme "sait" que fvect d�finit un tableau de float.

A partir de cette instruction, on peut acc�der a fvect comme dans
le premier exercice.

La memoire utilisee par fvect n'est pas definie lors de la COMPILATION
mais bien au moment de l'EXECUTION.

A la fin de l'execution du programme, on DOIT signaler au systeme
d'exploitation qu'on n'a plus besoin de la memoire

	free (fvect)


En r�sum�
---------

Une allocation dynamique comprend trois etapes

- definition du pointeur 	   : float * fvect
- l'allocation proprement dite : fvect = (float *) malloc...
- la liberation de la memoire  : free fvect

L'emploi de malloc impose d'inclure la biblioth�que

	#include <alloc.h>

------------------------------*/
