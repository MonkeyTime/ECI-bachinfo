/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique

Programme :

Phase 10
- Ultime astuce
------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float *fnew;  			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire realloue                  */
 float ftrav;           /* variable de transfert                      */

 int   vsize;			/* la taille du vecteur  					  */
 int   idx;				/* index qui d�finit le niveau de remplissage */
 int   incr;			/* incrementation de la taille du vecteur     */

 char  crep;			/* pour stocker la reponse a une question     */
 int   ierror;          /* indicateur d'erreur                        */       

 clrscr();
						/*---definition de la taille--*/

 fvect =  0;            /* le pointeur ne pointe sur RIEN             */
 vsize =  0;			/* le vecteur ne contient AUCUNE cellule      */
 idx   = -1;			/* il n'y a rien dans le vecteur			  */
 incr  =  3;			/* ajouter les cellules par paquets de incr   */
 ierror=  0;            /* variable de signalisation d'erreur         */

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire autant de nombres que vous voulez\n");

 do
	 {
							/* on demande un nombre     */
	  printf ("\nNombre [%2d] : ", idx+2);
	  scanf("%f", &ftrav);

						/*---- espace disponible ?----*/

	  if (idx >= vsize-1)
		 {                  /* demande de reallocation  */
		  fnew = (float *) realloc (fvect, (vsize+incr)*sizeof(float));
       
          ierror = !fnew;
          if (ierror)       /* echec                    */
             { 
              printf ("Memoire insuffisante !\n"
                      "Ajout impossible\n"
                      "Appuyez sur une touche pour continuer\n");
              getch();
             }
          else              /* reussite                 */
             {
              fvect = fnew;
              vsize += incr;

    		  printf("\nOn a ajoute %d cellules"
	    			 "\nIl y en a %d en tout\n",
		    			incr, vsize);
             }
		 }

						/*-------- stockage ----------*/

      if (!ierror)
         { 
    	  idx++;
	      fvect[idx]=ftrav;

          printf ("%d cellules sont occupees\n", idx+1);
         }

						/*---- suite de la saisie ?---*/

	  printf ("On continue [o/n] ? ");
	  crep = getche();

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

Dans la version precedente, le positionnement de ierror se faisant dans
les branches du test :

    if (fnew)
       {
        ierror=0;            
        :
       }
    else
       { 
        ierror=1;            
        :
       }

Si fnew est VRAI (non 0), alors ierror est FAUX (0)
Sinon fnew est FAUX (0), alors ierror est VRAI (1)

Dans un cas comme dans l'autre, ierror est le contraire de fnew.
Puisque le meme raisonnement s'applique dans chaque branche du test, il
peut etre sorti du if, ce qui s'ecrit

    ierror = !fnew;

On modifie le test pour utiliser cette valeur
L'ensemble est plus rapide, plus compact et plus lisible;

NOTE

On pourrait profiter de la compacit� du langage C et ecrire

ierror = !(fnew = (float *)realloc(fvect,(vsize+incr)*sizeof(float)));

(attention a la position des parentheses)

------------------------------*/
