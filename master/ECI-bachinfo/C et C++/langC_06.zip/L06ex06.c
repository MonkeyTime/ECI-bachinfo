/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique
- R�allocation

Programme :

Phase 6
- inverser le test de saturation de la pile

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */

 int   vsize;			/* la taille du vecteur  					  */
 int   idx;				/* index qui d�finit le niveau de remplissage */
 int   incr;			/* incrementation de la taille du vecteur     */

 char  crep;			/* pour stocker la reponse a une question     */


 clrscr();
						/*---definition de la taille--*/

 vsize =  5;			/* on prevoit deja vsize cellules	    	  */
 idx   = -1;			/* il n'y a rien dans le vecteur			  */
 incr  =  3;			/* ajouter les cellules par paquets de incr   */


						/*---------allocation---------*/

 fvect = (float *) malloc (vsize * sizeof(float));

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire autant de nombres que vous voulez\n");

 do
	 {
							/* on demande un nombre */
	  printf ("\nNombre [%2d] : ", idx+2);
	  scanf("%f", &ftrav);

							/* d�bordement ?        */
	  if (idx >= vsize-1)
		 {					/* oui, faire de la place et ajouter */
		  vsize+=incr;
		  fvect = (float *) realloc (fvect, vsize * sizeof(float));

		  printf("\nOn a ajoute %d cellules"
				 "\nIl y en a %d en tout\n",
					incr, vsize);
		 }

	  idx++;
	  fvect[idx]=ftrav;

      printf ("%d cellules sont occupees\n", idx+1);

						/*---- suite de la saisie ?---*/

	  printf ("On continue [o/n] ? ");
	  crep = getche();

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

En examinant le test de saturation de la pile, on s'aper�oit que des
instructions identiques se retrouvent dans les deux branches.

    if (idx < vsize-1)
  	   {
  	    idx++;                  // <<<<    
  	    fvect[idx]=ftrav;       // <<<<
  	   }
    else
  	   {
  	    vsize+=incr;
  	    fvect = (float *) realloc (fvect, vsize * sizeof(float));
 
  	    idx++;                  // <<<<
  	    fvect[idx]=ftrav;       // <<<<
       }

Comme elles sont situ�es A LA FIN de chaque branche, elles peuvent
sortir du if et se placer APRES.

    if (idx < vsize-1)
  	   {
  	   }
    else
  	   {
  	    vsize+=incr;
  	    fvect = (float *) realloc (fvect, vsize * sizeof(float));
       }
 
    idx++;                  // <<<<
    fvect[idx]=ftrav;       // <<<<

Dans ce cas, la branche "then" du if est vide (ce qui est l�gal mais pas
�l�gant).  Il suffit de prendre l'inverse du test pour que tout rentre
dans l'ordre.  Rappelons que l'inverse de < est >=

    if (idx >= vsize-1)
  	   {
  	    vsize+=incr;
  	    fvect = (float *) realloc (fvect, vsize * sizeof(float));
       }
 
    idx++;                  // <<<<
    fvect[idx]=ftrav;       // <<<<
 
------------------------------*/
