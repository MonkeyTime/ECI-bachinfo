/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique

Programme :

Phase 9
- V�rification de l'allocation
- Minimiser les degats
------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float *fnew;  			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire realloue                  */
 float ftrav;           /* variable de transfert                      */

 int   vsize;			/* la taille du vecteur  					  */
 int   idx;				/* index qui d�finit le niveau de remplissage */
 int   incr;			/* incrementation de la taille du vecteur     */

 char  crep;			/* pour stocker la reponse a une question     */
 int   ierror;          /* indicateur d'erreur                        */        

 clrscr();
						/*---definition de la taille--*/

 fvect =  0;            /* le pointeur ne pointe sur RIEN             */
 vsize =  0;			/* le vecteur ne contient AUCUNE cellule      */
 idx   = -1;			/* il n'y a rien dans le vecteur			  */
 incr  =  3;			/* ajouter les cellules par paquets de incr   */
 ierror=  0;            /* variable de signalisation d'erreur         */ 

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire autant de nombres que vous voulez\n");

 do
	 {
							/* on demande un nombre     */
	  printf ("\nNombre [%2d] : ", idx+2);
	  scanf("%f", &ftrav);

						/*---- espace disponible ?----*/

	  if (idx >= vsize-1)
		 {                  /* demande de reallocation  */
		  fnew = (float *) realloc (fvect, (vsize+incr)*sizeof(float));
        
          if (fnew)         /* reussite ?               */
             {
              ierror=0;             
              fvect = fnew;
              vsize += incr;

    		  printf("\nOn a ajoute %d cellules"
	    			 "\nIl y en a %d en tout\n",
		    			incr, vsize);
             }
          else              /* echec (sans quitter)     */
             {  
              ierror=1;             
              printf ("Memoire insuffisante !\n"
                      "Ajout impossible\n" 
                      "Appuyez sur une touche pour continuer\n");
              getch();
             }
		 }

						/*-------- stockage ----------*/

      if (!ierror)
         {  
    	  idx++;
	      fvect[idx]=ftrav;

          printf ("%d cellules sont occupees\n", idx+1);
         }

						/*---- suite de la saisie ?---*/

	  printf ("On continue [o/n] ? ");
	  crep = getche();

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:

Lors de l'echec de realloc, c'est la demande de nouvelle memoire qui a
pos� un probl�me.  Des lors, le recopie des donnees et la liberation du
premier vecteur n'ont pas �t� effectuees.  La doc precise que le bloc
original n'a pas ete modifie

Il est donc possible de conserver ce qui a deja ete introduit en memoire
bien qu'il soit impossible d'ajouter de nouveaux elements.

Le principe consiste a tenter la reallocation sans rien modifier par
ailleurs tant que l'on n'est pas sur de la reussite de l'operation

    vsize+=incr;
    fvect = (float *) realloc (fvect, vsize * sizeof(float));

devient

    fnew = (float *) realloc (fvect, (vsize+incr)*sizeof(float));

Notez que:

- on ne modifie plus vsize AVANT l'appel � realloc ainsi, en cas
  d'echec, vsize garde son ancienne valeur
- on demande un bloc de (vsize+incr) elements
- on recupere l'adresse dans un AUTRE pointeur fnew ainsi, en cas
  d'echec, l'adresse qui etait dans fvect est inchangee

On teste ensuite le succes de l'operation.
Si fnew est non nul, c'est que l'operation a reussi, donc le bloc de
memoire dont l'adresse se trouvait dans fvect a ete libere

    if (fnew)         // reussite
     {
      fvect = fnew;
      vsize += incr;
     }

L'adresse contenue dans fvect est devenue obsolete. On peut donc copier
l'adresse du nouveau bloc, contenue dans fnew, dans le pointeur fvect.
(fnew sert uniquement de pointeur temporaire pour l'allocation tandis
que fvect est le pointeur utilise dans le reste du programe)

On peut aussi acter le fait que la taille du vecteur a ete augmentee de
incr.

ATTENTION

Dans cette version, le bloc qui s'occupe de la verification de l' espace
et de la reallocation eventuelle est INDEPENDANT du bloc qui se charge
du stockage proprement dit (plus tard, nous en ferons des fonctions)

Il faut que le premier bloc signale au suivant s'il a rencontr� une
erreur.  C'est le role de la variable ierror.

Cette variable est declaree et DOIT �tre initialisee (ici, � 0);
Lors de la reallocation:

- elle est (re)mise � 0 en cas de succes
- elle est mise � 1 en cas d'echec

Le bloc suivant n'effectue le stockage et incremente l'index QUE s'il
n'y a pas eu de probleme�:

    if (!ierror)
       {  
    	idx++;
	    fvect[idx]=ftrav;
       }

En �vitant de quitter le programme lors de la saturation de la memoire,
on permet a l'utilisateur de prendre certaines actions.  Il pourrait par
exemple :

- decider d'arreter,
- supprimer d'anciennes valeurs,
- sauver sur disque,
- etc.

Mais dans tous les cas, son travail n'aura pas ete perdu.
------------------------------*/
