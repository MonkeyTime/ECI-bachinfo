/*------------------------------
LANGAGE C - H. Schyns

Le�on 6 - Exercice 3
- Allocation dynamique
- R�allocation

Programme :

Phase 5
- laisser la taille indefinie
- augmenter automatiquement la taille en fonction
  des besoins avec realloc

------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <alloc.h>

void main (void)
{
 float *fvect;			/* pointeur qui contiendra l'adresse de       */
						/* l'espace m�moire (qui n'existe pas encore) */
 float ftrav;           /* variable de transfert                      */

 int   vsize;			/* la taille du vecteur  					  */
 int   idx;				/* index qui d�finit le niveau de remplissage */
 int   incr;			/* incrementation de la taille du vecteur     */

 char  crep;			/* pour stocker la reponse a une question     */


 clrscr();
						/*---definition de la taille--*/

 vsize =  5;			/* on prevoit deja vsize cellules	    	  */
 idx   = -1;			/* il n'y a rien dans le vecteur			  */
 incr  =  3;			/* ajouter les cellules par paquets de incr   */


						/*---------allocation---------*/

 fvect = (float *) malloc (vsize * sizeof(float));

 clrscr();
						/*---- saisie des nombres ----*/

 printf ("Vous pouvez introduire autant de nombres que vous voulez\n");

 do
	 {
							/* on demande un nombre */
	  printf ("\nNombre [%2d] : ", idx+2);
	  scanf("%f", &ftrav);

							/* y a-t-il encore de la place ? */
	  if (idx < vsize-1)
		 {              	/* oui, ajouter */
		  idx++;
		  fvect[idx]=ftrav;
		 }
	  else
		 {					/* non, faire de la place et ajouter */
		  vsize+=incr;
		  fvect = (float *) realloc (fvect, vsize * sizeof(float));

		  idx++;
		  fvect[idx]=ftrav;

		  printf("\nOn a ajoute %d cellules"
				 "\nIl y en a %d en tout"
				 "\nDont %d occupees\n\n",
					incr, vsize, idx+1);
		 }

						/*---- suite de la saisie ?---*/

	  printf ("On continue [o/n] ? ");
	  crep = getche();

	 }while( (crep=='o') || (crep=='O') );

						/*---------liberation---------*/

 free (fvect);
						/*----------sortie------------*/

 printf ("\nMerci !\nAppuyez sur une touche pour quitter");
 getch();
}

/*------------------------------
Explications:


Au lieu de demander � l'utilisateur combien de donn�es il
compte stocker, on alloue un petit vecteur de vsize (5) cellules

	vsize =  5;
	idx   = -1;
	incr  =  3;

A ce stade, il n'y a encore rien dans ce vecteur donc l'index qui indique la derniere cellule remplie est en dehors du vecteur (-1). Il remplace le i du programme precedent.

Quand le vecteur sera plein, on ajoutera des cellules par paquets
de incr (3)

Dans le vecteur, les elements sont numerotes de

	[0]...[vsize-1]

donc, si

	idx = vsize-1

alors, c'est que le dernier element occupe la derniere cellule
du vecteur et il n'y a plus de place pour ajouter le nouveau
nombre.

On augmente le nombre de cellules (�l�ments) que l'on veut voir dans le vecteur :

    vsize+=incr;

On demande au syst�me d'exploitation de r�allouer un espace plus grand au vecteur fvect. C'est le r�le de la fonction realloc.

    fvect = (float *) realloc (fvect, vsize * sizeof(float));

La fonction realloc

- reserve un AUTRE bloc de m�moire contigue (en principe plus grand mais
  on peut aussi demander de r�server moins d'espace)

    vsize * sizeof(float)

  Ce bloc de m�moire n'est pas n�cessairement au m�me endroit que le
  bloc r�serv� par malloc

- COPIE toutes les donn�es du vecteur initial vers le nouveau bloc de
  m�moire (il faut donc lui fournir fvect, l'adresse du bloc initial)

- lib�re la m�moire occup�e par le bloc initial

- renvoie l'adresse du nouveau bloc (il faut donc r�cup�rer cette 
  adresse puisque le vecteur a chang� de place).

Ceci fait, on peut continuer � ins�rer des valeurs dans le vecteur

------------------------------*/
