/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 2
- printf

Programme :
Hello world : afficher un message
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 printf("Hello world!");
 getch();
}

/*------------------------------
Explications :

#include <conio.h>
stdio.h est le fichier d'en-tete qui contient la description de la   
fonction getch.

getch();
getch est une fonction qui attend la frappe d'une touche quelconque du 
clavier. Ceci emp�che Borland de revenir directement dans la fen�tre du 
programme source : tant qu'on n'a pas frapp� une touche, le programme 
n'est pas termin� et la fen�tre d'affichage reste la fen�tre active.
------------------------------*/
