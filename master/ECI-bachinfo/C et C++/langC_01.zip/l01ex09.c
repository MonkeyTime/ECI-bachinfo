/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 9
- Saisie d'un caract�re par getch()

Programme :
Lire deux nombres r�els et un caract�re (op�rateur math�matique)
puis afficher l'expression math�matique
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 float x, y;
 char opx;
 printf ("Entrez deux nombres: ");
 scanf ("%f%f",&x,&y);
 printf ("Entrez + - * / ");
 opx=getch();     				/* remplace scanf ("%c",&opx); */
 clrscr();
 printf ("vous avez tape %f %c %f\n", x, opx, y);
 getch();
}

/*------------------------------
Explications :

scanf r�cup�re les deux nombres r�els introduits au clavier. Comme il 
s'agit de deux r�els, le format est %f%f.  Les deux nombres pourront 
�tre introduits sur une m�me ligne, s�par�s par un espace (p.ex: 3.14 
2.25) ou l'un apr�s l'autre. scanf ne va pas plus loin tant qu'on ne lui 
a pas donn� ce qu'il attend.

getch attend la frappe d'un caract�re au clavier.  Ce caract�re est 
stock� dans la variable opx.  Le fonctionnement de getch est donc 
diff�rent de celui de scanf.

AVERTISSEMENT
Ce programme n'est pas capable d'interpr�ter le caract�re 
introduit (+ - * /).  A ce stade, il n'est pas possible de calculer 
l'expression affich�e.
------------------------------*/
