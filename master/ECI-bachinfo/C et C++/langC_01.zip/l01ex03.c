/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 3
- printf

Programme :
Affecter et afficher un nombre en fonction du type de variable
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 char cc;
 int ia;
 unsigned int ub;
 float ff;
 double dr;

 cc ='x';
 ia = -17;
 ub = 325;
 ff = 3.14159;
 dr = 1.414213562373095;

 printf ("%c\n", cc);  /* %c est le format pour ecrire un caractere isole */
 printf ("%d\n", ia);  /* %d est le format pour ecrire un entier signe */
 printf ("%u\n", ub);  /* %u est le format pour ecrire un entier positif */
 printf ("%f\n", ff);  /* %f est le format pour ecrire un nombre reel */
 printf ("%lf\n", dr); /* %lf est le format pour ecrire un nombre double pr�cision */

 getch(); 
}

/*------------------------------
Explications :

char cc;
cc ='x';
La variable cc est d�finie pour conserver un caract�re (1 byte) (cod� 
sous la forme d'un nombre compris entre -128 et 127). Lors de 
l'affectation (stockage) les caract�res sont introduits entre 
apostrophes.

int ia;
ia = -17;
La variable ia est d�finie pour conserver un nombre de 2 bytes compris 
entre -32768 et +32767. Lors de l'affectation les nombres sont 
introduits sous la forme habituelle.

unsigned int ub;
ub = 325;
La variable ub est d�finie pour conserver un nombre non-sign�, c-�-d 
TOUJOURS positif, de 2 bytes. La valeur peut �tre comprise entre 0 et 
+65535. Lors de l'affectation les nombres sont introduits sous la forme 
habituelle.

float ff;
ff = 3.14159;
La variable ff est d�finie pour conserver un nombre r�el, c-�-d un 
nombre pourvu d'une partie d�cimale. Un nombre r�el est stock� dans une 
variable de 4 bytes de long. Lors de l'affectation les nombres r�els 
sont introduits soit sous la forme habituelle, soit sous la forme 
scientifique (6.02E+23) o� E repr�sente "*10 exposant". Un "float" a 
une pr�cision de 7 chiffres significatifs

double dr;
dr = 1.414213562373095;
La variable dr est d�finie pour conserver un nombre r�el en double 
pr�cision stock� dans une variable de 8 bytes de long. Lors de 
l'affectation un "double" est introduit comme les "float": soit sous la 
forme habituelle, soit sous la forme scientifique. Un "double" a une 
pr�cision de 15 chiffres significatifs. Il existe aussi un type "long 
double" encore plus pr�cis, cod� sur 10 bytes.

------------------------------*/
