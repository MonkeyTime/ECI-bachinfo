/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 8
- Types de variables
- printf et scanf

Programme :
Lire un nombre entier, un r�el et un caract�re
puis afficher les valeurs lues
------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int a;
 float b; 
 char opx;
 printf ("Entrez un nombre entier et un nombre reel : ");
 scanf ("%d%f",&a,&b);
 printf ("Entrez un caractere: ");
 scanf ("%c",&opx);
 clrscr();
 printf ("vous avez tape %d %c %f\n", a, opx, b);
 getch();
}

/*------------------------------
Explications :

stdio.h est le fichier d'en-tete qui contient la description des  
fonctions printf, scanf et getch utilis�es dans le programme. Tout  
programme C commence par inclure les fichiers d'en-tete necessaires On  
conna�t les fichiers d'en-tete en consultant l'aide par [CTRL][F1]  
lorsque le curseur est positionne sur le nom de la fonction.  Notez le # 
(di�se) et les d�limiteurs <>.

main est TOUJOURS le nom du programme principal ou, plus exactement, le 
point d'entr�e d'un programme quelconque.  Le mot "void" signifie que ce 
programme ne demande aucun param�tre et ne retourne aucune valeur.  Le 
nom de l'ex�cutable est le nom du fichier dans lequel se trouve la 
fonction "main".

int, float, char caract�risent des variables de type entier, r�el ou 
caract�re.

printf permet d'afficher un message � l'�cran (mode DOS).  Le message � 
afficher est mis entre guillemets.

scanf r�cup�re les donn�es introduites au clavier.  On doit pr�ciser le 
type des donn�es introduites : %d = entier; %f = reel; %c = caract�re.  
On donne �galement l'adresse des variables dans lesquelles scanf doit 
stocker le r�sultat. L'adresse est le nom de la variable pr�c�d� de & 
(ampersand).

Notez qu'une instruction scanf est g�n�ralement pr�c�d�e d'une 
instruction printf qui explique ce que l'on doit entrer au clavier.

clrscr provoque l'effacement de l'�cran. Notez les parenth�ses, 
OBLIGATOIRES dans toute fonction C.

printf permet aussi d'afficher les valeurs contenues dans plusieurs 
variables.  Pour cela, il faut lui fournir le nom et le format (%d, %f, 
%c) des variables � afficher.  Notez que le format est inclus dans la 
ligne de texte alors que les variables sont en dehors, s�par�es par des 
virgules. \n provoque le saut � la ligne.

getch attend la frappe d'un caract�re au clavier.  Ce caract�re peut 
�ventuellement �tre stock� dans une variable (cf exercice suivant) mais 
ce n'est pas obligatoire.

AVERTISSEMENT
Ce programme ne semble pas afficher le caract�re lu dans 
la variable opx.  Nous verrons dans l'exercice suivant comment saisir un 
caract�re isol�.
------------------------------*/
