/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 6
- affectations

Programme :
depassement de capacite
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib, resu;
 ia = 20000;
 ib = 25000;
 resu = ia + ib; 	

 printf ("%d + %d = %d\n", ia, ib, resu); /* le r�sultat n'est pas 45000 ! */
 getch(); 
}

/*------------------------------
Explications :

printf ("%d + %d = %d\n", ia, ib, resu);
Le r�sultat affich� n'est pas celui que l'on attend: resu est une 
variable de type entier, pr�vue pour recevoir un nombre compris entre 
-32768 et +32767. Or, la somme ia+ib est sup�rieure � 32767! resu est 
donc incapable de stocker correctement ce nombre. Il faudrait utiliser 
une variable de type "long" qui peut stocker les nombres de -2147483648 
� +2147483647

------------------------------*/

