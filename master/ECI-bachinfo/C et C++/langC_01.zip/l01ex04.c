/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 4
- printf

Programme :
afficher un nombre selon un type different
parfois utile, souvent surprenant
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 char cc;
 int ia;
 unsigned int ub;
 float ff;
 double dr;

 cc ='x';
 ia = -17;
 ub = 325;
 ff = 3.14159;
 dr = 1.414213562373095;

 printf ("%d\n", cc);  /* on ontient le code ascii */
 printf ("%u\n", ia);  /* le bit de signe est traite comme un bit de valeur */
 printf ("%f\n", ub);  /* oops */
 printf ("%d\n", ff);  /* oops */
 printf ("%c\n", dr);  /* oops */

 getch(); 
}

/*------------------------------
Explications :

Comme les formats dans printf ne correspondent pas au type de variable, 
printf essaie d'interpr�ter les bytes qu'on lui a fourni : soit trop, 
soit trop peu.

------------------------------*/
