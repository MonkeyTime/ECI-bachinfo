/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 1
- printf

Programme :
Hello world : afficher un message
------------------------------*/
#include <stdio.h>

void main (void)
{
 printf("Hello world!");
}

/*------------------------------
Explications :

#include <stdio.h>
stdio.h est le fichier d'en-tete qui contient la description de la   
fonction printf. Tout  programme C commence par inclure les fichiers 
d'en-tete necessaires On  conna�t les fichiers d'en-tete en consultant 
l'aide par [CTRL][F1]  lorsque le curseur est positionne sur le nom de 
la fonction.  Notez le # (di�se) et les d�limiteurs <>.

void main (void)
main est TOUJOURS le nom du programme principal ou, plus exactement, le 
point d'entr�e d'un programme quelconque.  Le mot "void" signifie que ce 
programme ne demande aucun param�tre et ne retourne aucune valeur.  Le 
nom de l'ex�cutable est le nom du fichier dans lequel se trouve la 
fonction "main".

printf("Hello word!");
printf permet d'afficher un message � l'�cran (mode DOS).  Le message � 
afficher est mis entre guillemets.

NOTEZ le point-virgule (;) � la fin de l'instruction printf.

AVERTISSEMENT
Ce programme ne semble pas afficher le message. En fait, tout se passe 
tellement vite que Borland C affiche le message dans une fen�tre 
d'affichage et revient directement dans la fen�tre du programme source. 
Pour voir la fen�tre d'affichage, faire [ALT][F5]
------------------------------*/
