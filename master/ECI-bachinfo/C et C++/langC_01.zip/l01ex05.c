/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 5
- printf

Programme :
affecter et afficher un resultat d'une operation
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib, resu;
 ia = 38;
 ib = 75;
 resu = ia+ib;
 printf ("%d + %d = %d\n", ia, ib, resu);
 printf ("%d + %d = %d\n", ia, ib, ia+ib);

 getch(); 
}

/*------------------------------
Explications :

resu = ia+ib;
L'addition est r�alis�e avec les valeurs comprises dans ia et ib et le 
r�sultat est stock� dans la variable resu

printf ("%d + %d = %d\n", ia, ib, resu);
Tous les formats d'affichage sont inclus dans la cha�ne de caract�res 
d�limit�e par des guillemets. Les variables sont pr�sent�es en dehors de 
la cha�ne, selon l'ordre dans lequel elles seront utilis�es.
\n est le caract�re de saut � la ligne suivante.

printf ("%d + %d = %d\n", ia, ib, ia+ib);
Au lieu de faire le calcul et de stocker le r�sultat dans resu, on peut 
mettre le calcul dans l'instruction printf. Celui-ci sera effectu� et le 
r�sultat sera transmis � printf pour affichage.

------------------------------*/
