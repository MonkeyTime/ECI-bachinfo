/*------------------------------
LANGAGE C - H. Schyns

Le�on 1 - Exercice 6
- affectations

Programme :
affecter et afficher un resultat d'une operation
-----------------------------------*/
#include <stdio.h>
#include <conio.h>

void main (void)
{
 int ia, ib, resu;
 ia = ib = resu = 0;	/* initialisations en cascade */

 printf ("%d + %d = %d\n", ia=38, ib=75, resu=ia+ib);
 getch(); 
}
/*------------------------------
Explications :

ia = ib = resu = 0; 
Quand plusieurs variables doivent prendre la m�me valeur, C permet les 
initialisations en cascade. Dans la pluspart des autres langages, il 
aurait fallu �crire :
ia = 0;
ib = 0;
resu = 0;

printf ("%d + %d = %d\n", ia=38, ib=75, resu=ia+ib);
Il est permis de faire des affectations directement dans les fonctions. 
Ici, la valeur 38 est stock�es dans ia puis cette valeur est transmise � 
printf pour affichage. Il en va de m�me avec ia+ib dont le r�sultat est 
stock� dans resu puis transmis � printf pour affichage.

------------------------------*/

